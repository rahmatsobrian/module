#!/system/bin/sh

MODULE_DIR="/data/adb/modules/RaiRin-AI"
ENGINE_DIR="$MODULE_DIR/engine"
SOURCE_RENDER="$MODULE_DIR/render"
TARGET_BASE="/data/local/tmp/RaiRin-AI"
TARGET_RENDER="$TARGET_BASE/render"
TMP_ICON="/data/local/tmp/rairin.webp"
TMP_ICON2="/data/local/tmp/spicy.webp"

mkdir -p "$TARGET_BASE"
mkdir -p "$TARGET_RENDER"

if [ -f "$MODULE_DIR/kernel_panic.sh" ]; then
    cp -f "$MODULE_DIR/kernel_panic.sh" "$TARGET_BASE/"
    chmod +x "$TARGET_BASE/kernel_panic.sh"
fi

if [ -f "$MODULE_DIR/RaiRin-Boost" ]; then
    cp -f "$MODULE_DIR/RaiRin-Boost" "$TARGET_BASE/"
    chmod +x "$TARGET_BASE/RaiRin-Boost"
fi

if [ ! "$(ls -A "$TARGET_RENDER" 2>/dev/null)" ]; then
    if [ -d "$SOURCE_RENDER" ]; then
        cp -rf "$SOURCE_RENDER/." "$TARGET_RENDER/"
        rm -rf "$SOURCE_RENDER"
    fi
fi

if [ -d "$TARGET_RENDER" ]; then
    chmod -R 0755 "$TARGET_RENDER"
fi

find "$ENGINE_DIR" -type f ! -name "*.txt" -exec chmod 0755 {} \; 2>/dev/null

if [ -f "$MODULE_DIR/rairin.webp" ]; then
    cp -f "$MODULE_DIR/rairin.webp" "$TMP_ICON"
    chmod 644 "$TMP_ICON"
fi

if [ -f "$MODULE_DIR/spicy.webp" ]; then
    cp -f "$MODULE_DIR/spicy.webp" "$TMP_ICON2"
    chmod 644 "$TMP_ICON2"
fi

exit 0
