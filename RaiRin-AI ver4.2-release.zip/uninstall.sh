#!/system/bin/sh
pm uninstall bellavita.toast
rm -rf /data/local/tmp/RaiRin-AI
rm -f /data/local/tmp/licence.txt
rm -rf /data/local/tmp/thunder_default
rm -rf /data/local/tmp/govtrack
rm -rf /data/local/tmp/rairin_backup
rm -f /data/local/tmp/dex2oat.log
rm -f /data/local/tmp/rairin.webp