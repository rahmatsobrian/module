#!/system/bin/sh
MODULE_DIR="/data/adb/modules/RaiRin-AI/webroot/assets"
TMP_ICON="/data/local/tmp/spicy.webp"
TMP="/data/local/tmp/RaiRin-AI"
TMP_FILE="/data/local/tmp/rairin"

if [ -f "$MODULE_DIR/spicy.webp" ]; then
    cp -f "$MODULE_DIR/spicy.webp" "$TMP_ICON"
    chmod 644 "$TMP_ICON"
fi
su -lp 2000 -c "cmd notification post -S bigtext -t 'RaiRin-AI' RaiRin 'Invalid License — Contact @kaminarich for license'"
sleep 1
su -lp 2000 -c "/system/bin/cmd notification post \
    -t 'RaiRin-AI' \
    -i file://$TMP_ICON \
    -I file://$TMP_ICON \
    'RaiRin' 'Invalid License — Contact @kaminarich for license'"
if [ -f "$TMP_FILE" ]; then
    rm -f "$TMP_FILE"
    echo "File $TMP_FILE dihapus."
else
    echo "File $TMP_FILE tidak ditemukan."
fi
