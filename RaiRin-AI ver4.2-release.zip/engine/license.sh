#!/system/bin/sh
MODULE_DIR="/data/adb/modules/RaiRin-AI/webroot/assets"
TMP_ICON="/data/local/tmp/rairin.webp"
TMP="/data/local/tmp/RaiRin-AI"
TMP_FILE="/data/local/tmp/rairin"

# Pastikan direktori tmp ada
mkdir -p "$TMP"

# Buat file kosong rairin
touch "$TMP_FILE"
chmod 644 "$TMP_FILE"

# Jika ada ikon, salin ke tmp
if [ -f "$MODULE_DIR/rairin.webp" ]; then
    cp -f "$MODULE_DIR/rairin.webp" "$TMP_ICON"
    chmod 644 "$TMP_ICON"
fi

# Notifikasi teks biasa
su -lp 2000 -c "cmd notification post -S bigtext -t 'RaiRin-AI' RaiRin 'Valid License — Enjoy RaiRin-AI'"

# Notifikasi dengan ikon
su -lp 2000 -c "/system/bin/cmd notification post \
    -t 'RaiRin-AI' \
    -i file://$TMP_ICON \
    -I file://$TMP_ICON \
    'RaiRin' 'Valid License — Enjoy RaiRin-AI'"