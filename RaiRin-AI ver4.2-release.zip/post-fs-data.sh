#!/system/bin/sh

MODDIR="/data/adb/modules/RaiRin-AI"
SERVICE="$MODDIR/service.sh"
LOGFILE="/data/local/tmp/rairin_service.log"

chmod 755 "$SERVICE"
