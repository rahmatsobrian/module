#!/system/bin/sh

SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE="
"

print_modname() {
ui_print "░█▀▄░█▀█░▀█▀░█▀▄░▀█▀░█▀█░░░░░█▀█░▀█▀"
sleep 0.05
ui_print "░█▀▄░█▀█░░█░░█▀▄░░█░░█░█░▄▄▄░█▀█░░█░"
sleep 0.05
ui_print "░▀░▀░▀░▀░▀▀▀░▀░▀░▀▀▀░▀░▀░░░░░▀░▀░▀▀▀"
sleep 0.05
  ui_print ""
  sleep 1
  ui_print "Made by : kaminarich | kaminarich_here"
    ui_print ""
}

on_install() {
  # Definisikan target variable biar rapi
  RENDER_DIR="/data/local/tmp/RaiRin-AI/render"
  ui_print "> Stopping active processes..."
  pkill -f "RaiRin-AI" 2>/dev/null
  
  if [ -d "$RENDER_DIR" ]; then
    ui_print "> Cleaning old render files..."
    chattr -R -i "$RENDER_DIR" 2>/dev/null
    rm -rf "$RENDER_DIR"
    
    if [ -d "$RENDER_DIR" ]; then
        ui_print "! Warning: Failed to fully delete render folder."
        mv "$RENDER_DIR" "$RENDER_DIR.old" 2>/dev/null
        rm -rf "$RENDER_DIR.old"
    fi
  fi

  ui_print "> Merging into reality ..."
  sleep 2

  LICENSE_FILE="/data/adb/modules/RaiRin-AI/engine/license.txt"
  TMP_LICENSE="/data/local/tmp/license.txt"

  if [ -s "$LICENSE_FILE" ]; then
      ui_print "> License found, copy to tmp..."
      mkdir -p "$(dirname "$TMP_LICENSE")"
      cp "$LICENSE_FILE" "$TMP_LICENSE"
  else
      ui_print "> License empty"
  fi
  ui_print "> Extracting module files..."
  
  unzip -o "$ZIPFILE" 'action.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'gate.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'break.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'permission.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'RaiRin-Boost' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'cortex/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'engine/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'webroot/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'service.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'kernel_panic.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'post-fs-data.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'Toast.apk' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'uninstall.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'render/*' -d $MODPATH >&2 

  ui_print "> Installing Toast Application"
  pm install $MODPATH/Toast.apk
  ui_print " "
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0777 0777
}





