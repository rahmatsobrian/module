#!/system/bin/sh

RENDER_DIR="/data/local/tmp/RaiRin-AI/render"
MODULE_BIN="/data/local/tmp/RaiRin-AI/render"
RAIRIN_DIR="/data/adb/modules/RaiRin-AI"
FILE_ACTIVE="$RAIRIN_DIR/cortex/thunderclash/game-active.txt"
FILE_SKIA="$RENDER_DIR/skia.txt"
FILE_VULKAN="$RENDER_DIR/vulkan.txt"
BIN_SKIA="$MODULE_BIN/skia"
BIN_VULKAN="$MODULE_BIN/vulkan"

log_msg() {
    log -t "Render-Check" "$1"
    echo "$1"
}

if [ ! -f "$FILE_ACTIVE" ]; then
    log_msg "Error: $FILE_ACTIVE not found."
    exit 1
fi

PKG=$(cat "$FILE_ACTIVE" | tr -d '[:space:]')

if [ -z "$PKG" ]; then
    log_msg "no active package (empty list)."
    exit 0
fi

log_msg "checking render for: $PKG"

if [ -f "$FILE_SKIA" ] && grep -q -x "$PKG" "$FILE_SKIA"; then
    log_msg "Found Skia List. rum binary Skia..."
    
    if [ -f "$BIN_SKIA" ]; then
        chmod +x "$BIN_SKIA"
        

        "$BIN_SKIA"
    else
        log_msg "Error: Binary Skia not found at $BIN_SKIA"
    fi
    exit 0
fi

if [ -f "$FILE_VULKAN" ] && grep -q -x "$PKG" "$FILE_VULKAN"; then
    log_msg "Found Vulkan List. running binary Vulkan..."
    
    if [ -f "$BIN_VULKAN" ]; then
        chmod +x "$BIN_VULKAN"
        

        "$BIN_VULKAN"
    else
        log_msg "Error: Binary Vulkan not found at $BIN_VULKAN"
    fi
    exit 0
fi

log_msg "Package $PKG not found at list custom. using Default (no action)."
exit 0

