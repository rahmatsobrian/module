//  CORE EXECUTION WRAPPER 
function exec(command) {
  return new Promise((resolve, reject) => {
    const cb = `exec_cb_${Date.now()}_${Math.random().toString(36).substring(2)}`;
    window[cb] = (errno, stdout, stderr) => {
      delete window[cb];
      if (errno !== 0) reject(new Error(stderr || stdout || "Unknown error"));
      else resolve(stdout);
    };
    try { ksu.exec(command, `window.${cb}`); } 
    catch (e) { reject(e); }
  });
}

function execBg(command) {
    const detached = `nohup ${command} > /dev/null 2>&1 &`;
    return exec(detached);
}

//  PATHS 
const MOD_ROOT = "/data/adb/modules/RaiRin-AI";
const ASSETS_DIR = `${MOD_ROOT}/webroot/assets`;

const FILES = {

    banner: `${ASSETS_DIR}/banner.webp`,
    backup: `${ASSETS_DIR}/banner2.webp`,
    tmpPreview: `${ASSETS_DIR}/preview_temp`,
    bannerConfig: `${MOD_ROOT}/banner_config.json`,

    prop: `${MOD_ROOT}/module.prop`,
    soc: "/data/local/tmp/thunder_default/soc",

    render: "/data/local/tmp/RaiRin-AI/render/status.txt",
    net: `${MOD_ROOT}/cortex/net/booster.txt`,
    log: "/data/local/tmp/RaiRin-AI/log_option.txt",
    dexStatus: `${MOD_ROOT}/cortex/dex2oat/status.txt`,
    refreshStatus: `${MOD_ROOT}/cortex/thunderclash/refresh_status.txt`,
    license: `${MOD_ROOT}/engine/license.txt`,

    gameMode: `${MOD_ROOT}/cortex/gamemode/status.txt`,
    thermal: `${MOD_ROOT}/cortex/thermal/mode.txt`,
    thermalLite: `${MOD_ROOT}/cortex/thermal/lite-mode.txt`,
    thermalBatt: `${MOD_ROOT}/cortex/thermal/battery.txt`,
    gameFocus: `${MOD_ROOT}/cortex/gamemode/status.txt`,
    gamelist: `${MOD_ROOT}/cortex/thunderclash/gamelist.txt`,
    whitelist: `${MOD_ROOT}/cortex/thunderclash/whitelist.txt`,
    vulkanFile: "/data/local/tmp/RaiRin-AI/render/vulkan.txt",
    skiaFile: "/data/local/tmp/RaiRin-AI/render/skia.txt",
    defaultGov: `${MOD_ROOT}/cortex/cpu/default-gov.txt`,

    idleCpu: `${MOD_ROOT}/cortex/battery/mode.txt`,
    //battService: `${MOD_ROOT}/cortex/battery/mode.txt`,
    cpuPower: `${MOD_ROOT}/cortex/battery/powersave.txt`,
    //idleCpu: "/data/local/tmp/batteryhoney/power.txt",
    standby: "/data/local/tmp/RaiRin-AI/power.txt",
    bypass: `${MOD_ROOT}/cortex/bypass/status.txt`,

    binDex: `${MOD_ROOT}/cortex/dex2oat/dex`,
    binFlush: `${MOD_ROOT}/cortex/cache/flushram`,
    binPreload: `${MOD_ROOT}/cortex/preload-game/preload`,

    binRenderSkia: "/data/local/tmp/RaiRin-AI/render/skiagl-soft",
    binRenderVulkan: "/data/local/tmp/RaiRin-AI/render/vulkan-soft",
    
    binClear: `${MOD_ROOT}/cortex/cache/clear.sh`,
    binNetBoost: `${MOD_ROOT}/cortex/net/net-boost.sh`,
    binNetDefault: `${MOD_ROOT}/cortex/net/net-default.sh`,
    binLogEn: `${MOD_ROOT}/cortex/log/enable.sh`,
    binLogDis: `${MOD_ROOT}/cortex/log/disable.sh`,

    scriptRefresh: `${MOD_ROOT}/cortex/thunderclash/refresh.sh`,
    scriptCpuCtrl: `${MOD_ROOT}/cortex/cpu/cpu-control.sh`,
    scriptGov: `${MOD_ROOT}/cortex/cpu/gov.sh`,

    backupFile: "/data/local/tmp/rairinsettings.txt",
    backupBg: "/data/local/tmp/rairin_bg_backup.webp"
};

const DOWNLOAD_PATH = "/sdcard/Download";
const DAEMON_BIN = "RaiRin-game";
let bannerConfig = { darkness: 30, blur: 0 };

//  INIT 
document.addEventListener("DOMContentLoaded", async () => {
    initTheme();
    await loadBanner();
    await loadInfo(); 
    checkDaemon();
    setInterval(checkDaemon, 3000);

    // Setup Modals
    setupModalBehavior();

    // Main Menus
    setupBannerMenu();
    setupRenderMenu();
    setupRefreshMenu();
    setupChipsetMenu();
    
    // Special Menus
    setupNetMenu();
    setupDexMenu();
    setupRamCacheMenu();
    setupLogMenu();
    
    setupLicenseMenu();
    setupBackupMenu();

    // Game Menus
    setupGameModeMenu();
    setupThermalMenu();
    setupGameFocusMenu();
    setupAppListMenu();
    setupAppRenderMenu();
    setupGovMenu();
    setupCpuCtrlMenu();
    
    const btnPreload = document.getElementById("btnPreload");
    if (btnPreload) {
        btnPreload.onclick = async () => { 
            const modal = document.getElementById("modalPreload");
            const term = document.getElementById("preloadTerminal");
            const closeBtn = document.getElementById("closePreload");

            modal.classList.add("active");
            term.innerHTML = '<div style="color:#aaa; padding:10px;"><i class="fa-solid fa-spinner fa-spin"></i> Processing...</div>';
            
            closeBtn.onclick = () => modal.classList.remove("active");

            try {
                await exec(`chmod +x "${FILES.binPreload}"`);
                const output = await exec(`"${FILES.binPreload}"`);

                let formattedHtml = "";
                output.split('\n').forEach(line => {
                    if (!line.trim()) return;
                    
                    let style = "color: #e0e0e0;"; 
                    const lower = line.toLowerCase();
                    
                    if (lower.includes("error") || lower.includes("failed")) style = "color: #ff5555; font-weight:bold;";
                    else if (lower.includes("success") || lower.includes("done") || lower.includes("finished")) style = "color: #00ff00;";
                    else if (lower.includes("warning")) style = "color: #ffb86c;";
                    else if (line.trim().startsWith("->")) style = "color: #6272a4;";

                    formattedHtml += `<div style="${style} margin-bottom:2px;">${line}</div>`;
                });

                term.innerHTML = formattedHtml;

            } catch (err) {
                term.innerHTML = `<div style="color: #ff5555; font-weight:bold;">ERROR:</div><div style="color: #ff5555;">${err.message}</div>`;
            }
        };
    }

    setupIdleCpuMenu();
    setupSelectMenu("btnStandbyMenu", "modalStandby", "selectStandby", "displayStandby", "previewStandby", FILES.standby, "7");
    setupSelectMenu("btnPowerSaveMenu", "modalPowersave", "selectPowersave", "displayPowersave", "previewPowerSave", FILES.cpuPower, "50");
    setupSelectMenu("btnBypassMenu", "modalBypass", "selectBypass", "displayBypass", "previewBypass", FILES.bypass, "off");
    
    initColorBoost();
});

const LANG_MAP = {
    'en': 'eng.json',
    'ind': 'ind.json',
    'thai': 'thai.json',
    'hindi': 'hindi.json',
    'viet': 'viet.json',
    'arab': 'arab.json',
    'turkey': 'turkey.json',
    'rusia': 'rusia.json'
};

document.addEventListener("DOMContentLoaded", async () => {

    
    setupLangMenu();
    
    const savedLang = localStorage.getItem("rairin_lang") || "en";
    loadLanguage(savedLang);
});

function setupLangMenu() {
    const btn = document.getElementById("btnOpenLang");
    const modal = document.getElementById("modalLang");
    const close = document.getElementById("closeLang");

    if(btn) btn.onclick = () => modal.classList.add("active");
    if(close) close.onclick = () => modal.classList.remove("active");
    
    window.setLanguage = async (code) => {
        await loadLanguage(code);
        modal.classList.remove("active");
    };
}

async function loadLanguage(code) {
    const fileName = LANG_MAP[code] || 'eng.json';
    const filePath = `languages/${fileName}`;
    const display = document.getElementById("currentLangDisplay");
    if(display) display.innerText = code.toUpperCase();
    
    try {

        const response = await fetch(filePath);
        if (!response.ok) throw new Error("Lang missing");
        const translations = await response.json();        

        applyTranslations(translations);
        
        localStorage.setItem("rairin_lang", code);
        

        if(code === 'arab') {
            document.body.style.direction = 'rtl';
            document.body.style.textAlign = 'right';
        } else {
            document.body.style.direction = 'ltr';
            document.body.style.textAlign = 'left';
        }
        
    } catch (e) {
        console.error("Failed to load language:", e);
        if(code !== 'en') alert("Language file not found: " + fileName);
    }
}

function applyTranslations(data) {
    const elements = document.querySelectorAll("[data-i18n]");
    elements.forEach(el => {
        const key = el.getAttribute("data-i18n");
        if (data[key]) {

            if (el.tagName === 'INPUT' && el.hasAttribute('placeholder')) {
                el.placeholder = data[key];
            } else {
                el.innerText = data[key];
            }
        }
    });
}


//  THEME & MODAL 
function initTheme() {
    const toggle = document.getElementById("themeToggle");
    const stored = localStorage.getItem("rairin_theme") || "light";
    document.documentElement.setAttribute("data-theme", stored);
    if(toggle) {
        toggle.checked = stored === "dark";
        toggle.addEventListener("change", (e) => {
            const theme = e.target.checked ? "dark" : "light";
            document.documentElement.setAttribute("data-theme", theme);
            localStorage.setItem("rairin_theme", theme);
        });
    }
}

function setupModalBehavior() {
    const modals = document.querySelectorAll('.modal-backdrop');
    modals.forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.classList.remove('active');
        });
        const closeBtn = modal.querySelector('.close-icon');
        if(closeBtn) closeBtn.addEventListener('click', () => modal.classList.remove('active'));
    });
}

//  INFO SYSTEM 
async function loadInfo() {
    try {
        const ver = await exec(`grep "^version=" ${FILES.prop} | cut -d= -f2`);
        document.getElementById("infoVersion").innerText = ver.trim() || "Unknown";
    } catch {}

    try {
        const auth = await exec(`grep "^author=" ${FILES.prop} | cut -d= -f2`);
        document.getElementById("infoAuthor").innerText = auth.trim() || "Unknown";
    } catch { document.getElementById("infoAuthor").innerText = "Unknown"; }

    try {
        let chipId = (await exec(`cat ${FILES.soc} 2>/dev/null`)).trim();
        if(!chipId) chipId = localStorage.getItem("chipset_id") || "1";
        document.getElementById("infoChipsetDisplay").innerText = getChipName(chipId);
    } catch {}

    try { document.getElementById("infoKernel").innerText = (await exec("uname -r")).trim(); } catch {}
    try { document.getElementById("infoSDK").innerText = (await exec("getprop ro.build.version.sdk")).trim(); } catch {}
}

async function checkDaemon() {
    const icon = document.getElementById("serviceStatusIcon");
    const text = document.getElementById("servicePidText");
    try {
        const pid = await exec(`pidof ${DAEMON_BIN}`);
        if(pid && !isNaN(parseInt(pid))) {
            icon.className = "dot green"; text.innerText = "Online";
        } else { throw new Error(); }
    } catch {
        icon.className = "dot red"; text.innerText = "Offline";
    }
}

function getChipName(id) {
    const maps = { "1":"Mediatek", "2":"Snapdragon", "3":"Exynos", "4":"Unisoc", "5":"Tensor" };
    return maps[id] || "Unknown";
}

//  RAM TOOLS
function setupRamCacheMenu() {
    const btnMenu = document.getElementById("btnRamMenu");
    const modal = document.getElementById("modalRam");
    const term = document.getElementById("ramTerminal");
    
    btnMenu.onclick = () => {
        modal.classList.add("active");
        term.style.display = "block";
        term.innerText = "Ready.";
    };

    document.getElementById("doFlushRam").onclick = async () => {
        term.innerText = "> Running Flush RAM...";
        try {
            await exec(`chmod +x "${FILES.binFlush}"`);
            const output = await exec(`"${FILES.binFlush}"`);
            term.innerText = output || "Done (No Output).";
        } catch (e) { term.innerText = "Error: " + e.message; }
    };

    document.getElementById("doClearCache").onclick = async () => {
        term.innerText = "> Running Clear Cache...";
        try {
            await exec(`chmod +x "${FILES.binClear}"`);
            const output = await exec(`"${FILES.binClear}"`);
            term.innerText = output || "Cache Cleared!";
        } catch (e) { term.innerText = "Error: " + e.message; }
    };
}

//  DEX OPTIMIZATION 
function setupDexMenu() {
    setupToggleMenu("btnDexMenu", {
        title: "Dex2OAT", color: "pink", icon: "fa-solid fa-rocket",
        desc: "Optimize app bytecode on Gamelist. Please wait until Finish", label: "Optimize", previewId: "previewDex",
        terminalId: "toggleTerminal",
        
        checkState: async () => { return (await exec(`cat ${FILES.dexStatus} 2>/dev/null`)).trim() === "enabled"; },
        
        apply: async (state, log) => {
            try {
                if(state) {
                    log("> Enabling Dex2OAT...\n> Running binary (Long process)...");
                    await exec(`echo enabled > ${FILES.dexStatus}`);
                    await exec(`chmod +x "${FILES.binDex}"`);
                    const out = await exec(`"${FILES.binDex}"`); // Direct exec
                    log("> Output:\n" + (out || "Done"));
                } else {
                    await exec(`echo disabled > ${FILES.dexStatus}`);
                    log("> Dex2OAT Disabled.");
                }
                return true;
            } catch (e) { log("Error: " + e.message); return false; }
        }
    });
}

//  NET BOOSTER 
function setupNetMenu() {
    setupToggleMenu("btnNetMenu", {
        title: "Net Booster", color: "green", icon: "fa-solid fa-wifi",
        desc: "Boost internet speed.", label: "Active Mode", previewId: "previewNet",
        terminalId: "toggleTerminal",
        
        checkState: async () => { return (await exec(`cat ${FILES.net} 2>/dev/null`)).trim() === "Boost"; },
        
        apply: async (state, log) => {
            const opt = state ? "Boost" : "Default";
            const script = state ? FILES.binNetBoost : FILES.binNetDefault;
            log(`> Applying ${opt} Mode...`);
            try {
                await exec(`chmod +x "${script}"`);
                const out = await exec(`"${script}"`); // Direct Exec
                await exec(`echo ${opt} > ${FILES.net}`);
                log(`> Output:\n${out || "Success"}`);
                return true;
            } catch (e) { log("Error: " + e.message); return false; }
        }
    });
}

//  LOG MENU 
function setupLogMenu() {
    setupToggleMenu("btnLogMenu", {
        title: "Logs & Tracing", color: "gray", icon: "fa-solid fa-file-lines",
        desc: "Disable logs to improve performance.", label: "Enable Logs", previewId: "previewLog",
        terminalId: "toggleTerminal",
        
        checkState: async () => { return (await exec(`cat ${FILES.log} 2>/dev/null`)).trim() !== "disabled"; },
        
        apply: async (state, log) => {
            const opt = state ? "enabled" : "disabled";
            const script = state ? FILES.binLogEn : FILES.binLogDis;
            log(`> Setting ${opt}...`);
            try {
                await exec(`echo ${opt} > ${FILES.log}`);
                await exec(`chmod +x "${script}"`);
                const out = await exec(`"${script}"`); // Direct Exec
                log(`> Done.\n${out||""}`);
                return true;
            } catch { return false; }
        }
    });
}

//  THERMAL MONITOR 
function setupThermalMenu() {
    const btn = document.getElementById("btnThermalMenu");
    const modal = document.getElementById("modalThermal");
    

    const exToggle = document.getElementById("toggleThermalEx");
    const liToggle = document.getElementById("toggleThermalLite");
    const battToggle = document.getElementById("toggleThermalBatt");
    
    const preview = document.getElementById("previewThermal");

    const updateState = async () => {

        const ex = (await exec(`cat ${FILES.thermal} 2>/dev/null`)).trim();
        const li = (await exec(`cat ${FILES.thermalLite} 2>/dev/null`)).trim();
        const batt = (await exec(`cat ${FILES.thermalBatt} 2>/dev/null`)).trim();


        exToggle.checked = (ex === "on");
        liToggle.checked = (li === "on");
        battToggle.checked = (batt === "on");


        if (ex === "on") preview.innerText = "Extreme Active";
        else if (li === "on") preview.innerText = "Lite Active";
        else preview.innerText = "Inactive";
    };
    updateState();

    btn.onclick = () => { modal.classList.add("active"); updateState(); };


    exToggle.onchange = async () => {
        if(exToggle.checked) {
            liToggle.checked = false;
            await exec(`echo off > ${FILES.thermalLite}`);
            await exec(`echo on > ${FILES.thermal}`);
        } else {
            await exec(`echo off > ${FILES.thermal}`);
        }
        updateState();
    };

    liToggle.onchange = async () => {
        if(liToggle.checked) {
            exToggle.checked = false;
            await exec(`echo off > ${FILES.thermal}`);
            await exec(`echo on > ${FILES.thermalLite}`);
        } else {
            await exec(`echo off > ${FILES.thermalLite}`);
        }
        updateState();
    };

    battToggle.onchange = async () => {
        const val = battToggle.checked ? "on" : "off";
        await exec(`echo ${val} > ${FILES.thermalBatt}`);
        updateState(); 
    };
}

//  TOGGLE HELPER
function setupToggleMenu(btnId, config) {
    const btn = document.getElementById(btnId);
    if(!btn) return;
    const modal = document.getElementById("modalToggle");
    const check = document.getElementById("toggleInput");
    const term = document.getElementById("toggleTerminal");
    
    (async()=>{ const isOn = await config.checkState(); if(document.getElementById(config.previewId)) document.getElementById(config.previewId).innerText = isOn ? "Enabled" : "Disabled"; })();

    btn.onclick = async () => {
        document.getElementById("toggleTitle").innerText = config.title;
        document.getElementById("toggleIcon").className = `modal-hero-icon ${config.color}-glow`;
        document.getElementById("toggleIcon").innerHTML = `<i class="fa-solid ${config.icon}"></i>`;
        document.getElementById("toggleDesc").innerText = config.desc;
        document.getElementById("toggleLabel").innerText = config.label;
        
        if(config.terminalId) { term.style.display="block"; term.innerText="Waiting..."; } 
        else { term.style.display="none"; }
        
        modal.classList.add("active");
        const isOn = await config.checkState();
        check.checked = isOn;
        document.getElementById("toggleStatus").innerText = isOn ? "Current: Enabled" : "Current: Disabled";
        
        check.onchange = async () => {
            document.getElementById("toggleStatus").innerText = "Applying...";
            const newState = check.checked;
            const logFn = (msg) => { if(term && config.terminalId) term.innerText = msg; };
            
            const success = await config.apply(newState, logFn);
            if(success) {
                document.getElementById("toggleStatus").innerHTML = "<span style='color:var(--color-green)'>Success</span>";
                if(document.getElementById(config.previewId)) document.getElementById(config.previewId).innerText = newState ? "Enabled" : "Disabled";
            } else {
                document.getElementById("toggleStatus").innerText = "Failed";
                check.checked = !newState;
            }
        };
    };
}

//  APP LISTS 
async function getAppList() {
    try {
        const raw = await exec("pm list packages -3 | cut -f 2 -d :");
        return raw.trim().split("\n").sort();
    } catch { return []; }
}
function getAppIconHTML(pkg, name) {
    const letter = name.charAt(0).toUpperCase();
    const colors = ["#FF3B30", "#FF9500", "#FFCC00", "#4CD964", "#5AC8FA", "#007AFF", "#5856D6", "#FF2D55"];
    const color = colors[pkg.length % colors.length];
    return `<div class="app-avatar" style="background: linear-gradient(135deg, ${color}, #888);">${letter}</div>`;
}
function formatAppName(pkg) {
    const parts = pkg.split('.');
    if(parts.length > 1) {
        let name = parts[parts.length-1];
        return name.charAt(0).toUpperCase() + name.slice(1);
    }
    return pkg;
}

function setupAppListMenu() {
    const btn = document.getElementById("btnAppListMenu");
    const modal = document.getElementById("modalAppList");
    const select = document.getElementById("selectListType");
    const container = document.getElementById("appListContainer");
    const save = document.getElementById("btnSaveAppList");
    let loadedApps = [];
    
    btn.onclick = async () => {
        modal.classList.add("active");
        if(loadedApps.length === 0) {
            container.innerHTML = "<div style='text-align:center;padding:20px'>Loading installed apps...</div>";
            loadedApps = await getAppList();
        }
        renderList();
    };
    select.onchange = renderList;
    
    async function renderList() {
        const file = select.value === "game" ? FILES.gamelist : FILES.whitelist;
        document.getElementById("displayListType").innerText = select.options[select.selectedIndex].text;
        
        let currentList = [];
        try { currentList = (await exec(`cat ${file} 2>/dev/null`)).trim().split("\n"); } catch {}
        
        container.innerHTML = "";
        if(loadedApps.length === 0) { container.innerHTML = "<div style='text-align:center;padding:10px'>No 3rd party apps found.</div>"; return; }
        
        loadedApps.forEach(pkg => {
            if(!pkg) return;
            const name = formatAppName(pkg);
            const row = document.createElement("div");
            row.className = "app-list-item";
            const isChecked = currentList.includes(pkg);
            
            row.innerHTML = `
                ${getAppIconHTML(pkg, name)}
                <div class="app-info"><div class="app-name">${name}</div><div class="app-pkg">${pkg}</div></div>
                <label class="ios-switch"><input type="checkbox" class="app-check" value="${pkg}" ${isChecked?'checked':''}><span class="slider"></span></label>
            `;
            container.appendChild(row);
        });
    }
    
    save.onclick = async () => {
        save.innerText = "Saving...";
        const file = select.value === "game" ? FILES.gamelist : FILES.whitelist;
        const checks = container.querySelectorAll(".app-check:checked");
        let content = "";
        checks.forEach(c => content += c.value + "\n");
        const tmp = "/data/local/tmp/rairin_list_tmp";
        await exec(`echo "${content}" > ${tmp}`);
        await exec(`cat ${tmp} > ${file}`);
        await exec(`rm ${tmp}`);
        save.innerText = "Saved!";
        setTimeout(() => save.innerText = "Save Selection", 1500);
    };
}

function setupAppRenderMenu() {
    const btn = document.getElementById("btnAppRenderMenu");
    const modal = document.getElementById("modalAppRender");
    const container = document.getElementById("renderAppContainer");
    
    btn.onclick = async () => {
        modal.classList.add("active");
        container.innerHTML = "<div style='text-align:center;padding:20px'>Loading Gamelist...</div>";
        await exec(`mkdir -p /data/local/tmp/RaiRin-AI/render`);
        await exec(`touch ${FILES.vulkanFile}`); await exec(`touch ${FILES.skiaFile}`);
        
        const gl = (await exec(`cat ${FILES.gamelist} 2>/dev/null`)).split("\n").filter(l=>l.trim());
        const vk = (await exec(`cat ${FILES.vulkanFile} 2>/dev/null`)).split("\n");
        const sk = (await exec(`cat ${FILES.skiaFile} 2>/dev/null`)).split("\n");
        
        container.innerHTML = "";
        if(gl.length === 0) { container.innerHTML = "<div style='text-align:center;padding:10px'>No games in Gamelist.</div>"; return; }
        
        gl.forEach(pkg => {
            const name = formatAppName(pkg);
            const div = document.createElement("div");
            div.className = "app-list-item";
            let cur = "default";
            if(vk.includes(pkg)) cur = "vulkan";
            if(sk.includes(pkg)) cur = "skia";
            
            div.innerHTML = `
                ${getAppIconHTML(pkg, name)}
                <div class="app-info"><div class="app-name">${name}</div><div class="app-pkg">${pkg}</div></div>
                <select class="mini-select" data-pkg="${pkg}">
                    <option value="default" ${cur==='default'?'selected':''}>Default</option>
                    <option value="vulkan" ${cur==='vulkan'?'selected':''}>Vulkan</option>
                    <option value="skia" ${cur==='skia'?'selected':''}>Skia</option>
                </select>
            `;
            div.querySelector("select").addEventListener("change", async (e) => {
                const val = e.target.value;
                const p = e.target.getAttribute("data-pkg");
                let nVk = (await exec(`cat ${FILES.vulkanFile}`)).split("\n").filter(x=>x!==p && x.trim());
                let nSk = (await exec(`cat ${FILES.skiaFile}`)).split("\n").filter(x=>x!==p && x.trim());
                if(val==="vulkan") nVk.push(p);
                if(val==="skia") nSk.push(p);
                await exec(`echo "${nVk.join("\n")}" > ${FILES.vulkanFile}`);
                await exec(`echo "${nSk.join("\n")}" > ${FILES.skiaFile}`);
            });
            container.appendChild(div);
        });
    };
}

//  OTHER
function setupGameModeMenu() {
    setupToggleMenu("btnThunderMenu", {
        title: "Integrated Performance", color: "blue", icon: "fa-solid fa-bolt",
        desc: "Special Performance Mode.", label: "Thunder Mode", previewId: "previewThunder",
        checkState: async () => { return (await exec(`cat ${FILES.gameMode} 2>/dev/null`)).trim() === "on"; },
        apply: async (state) => { try { await exec(`echo "${state?"on":"off"}" > ${FILES.gameMode}`); return true; } catch { return false; } }
    });
}
function setupGameFocusMenu() {
    setupToggleMenu("btnGameFocusMenu", {
        title: "Game Focus", color: "purple", icon: "fa-solid fa-gamepad",
        desc: "Kill background apps except on Whitelist while Gaming to increase Free RAM", label: "Focus Mode", previewId: "previewGameFocus",
        checkState: async () => { return (await exec(`cat ${FILES.gameFocus} 2>/dev/null`)).trim() === "on"; },
        apply: async (state) => { try { await exec(`echo "${state?"on":"off"}" > ${FILES.gameFocus}`); return true; } catch { return false; } }
    });
}
function setupIdleCpuMenu() {
    setupToggleMenu("btnIdleMenu", {
        title: "Idle Mode", color: "green", icon: "fa-solid fa-leaf",
        desc: "Passive battery saver. Did not interrupting Performance!", label: "Idle Mode", previewId: "previewIdle",
        checkState: async () => { return (await exec(`cat ${FILES.idleCpu} 2>/dev/null`)).trim() === "on"; },
        apply: async (state) => { try { await exec(`echo "${state?"on":"off"}" > ${FILES.idleCpu}`); return true; } catch { return false; } }
    });
}

function setupTouchMenu() { setupToggleMenu("btnTouchMenu", { title: "Touch Response", color: "blue", icon: "fa-solid fa-fingerprint", desc: "Boost touch sampling.", label: "Touch Boost", previewId: "previewTouch", checkState: async () => { return (await exec(`cat ${FILES.touch} 2>/dev/null`)).trim() === "on"; }, apply: async (state) => { try { await exec(`echo "${state?"on":"off"}" > ${FILES.touch}`); return true; } catch { return false; } } }); }
function setupDndMenu() { setupToggleMenu("btnDndMenu", { title: "Do Not Disturb", color: "purple", icon: "fa-solid fa-bell-slash", desc: "Block notifications.", label: "Block All", previewId: "previewDnd", checkState: async () => { return (await exec(`cat ${FILES.dnd} 2>/dev/null`)).trim() === "on"; }, apply: async (state) => { try { await exec(`echo "${state?"on":"off"}" > ${FILES.dnd}`); return true; } catch { return false; } } }); }

//  STANDARD SELECTS & RENDER 
function setupRenderMenu() {
    const btn = document.getElementById("btnRenderMenu");
    const modal = document.getElementById("modalRender");
    const select = document.getElementById("selectRender");

    (async()=>{ 
        const cur = (await exec(`cat ${FILES.render} 2>/dev/null`)).trim(); 
        document.getElementById("previewRender").innerText = (cur==="skia"?"SkiaGL":(cur==="vk"?"Vulkan":"Default")); 
    })();

    btn.onclick = async () => {
        modal.classList.add("active");
        const cur = (await exec(`cat ${FILES.render} 2>/dev/null`)).trim();
        select.value = (cur==="skia"?"skiagl":(cur==="vk"?"vulkan":"default"));
    };

    select.onchange = async () => {
        const val = select.value;
        let fc = "default";
        let bin = "";

        if (val === "skiagl") { 
            fc = "skia"; 
            bin = FILES.binRenderSkia; 
        }
        if (val === "vulkan") { 
            fc = "vk"; 
            bin = FILES.binRenderVulkan; 
        }

        await exec(`echo "${fc}" > ${FILES.render}`);
        
        if(bin) { 
            await exec(`chmod +x "${bin}"`); 
            execBg(`"${bin}"`); 
        }

        document.getElementById("previewRender").innerText = select.options[select.selectedIndex].text;
    };
}

function setupRefreshMenu() {
    const btn = document.getElementById("btnRefreshMenu");
    const modal = document.getElementById("modalRefresh");
    const select = document.getElementById("selectRefresh");
    (async()=>{ const id = (await exec(`cat ${FILES.refreshStatus} 2>/dev/null`)).trim(); if(id) document.getElementById("previewRefresh").innerText = `Saved: ${id}`; })();
    btn.onclick = async () => {
        modal.classList.add("active");
        select.innerHTML = `<option disabled>Scanning...</option>`;
        try {
            const raw = await exec("dumpsys display | grep -o 'fps=[0-9.]*'");
            const rates = [...new Set((raw.match(/fps=([0-9.]+)/g)||[]).map(s=>Math.round(parseFloat(s.split('=')[1]))))].sort((a,b)=>b-a);
            select.innerHTML = `<option value="" disabled selected>Select Hz</option>`;
            rates.forEach((hz, idx) => { select.innerHTML += `<option value="${idx}">${hz} Hz</option>`; });
        } catch { select.innerHTML = `<option disabled>Failed</option>`; }
    };
    select.onchange = async () => {
        await exec(`sh ${FILES.scriptRefresh} ${select.value}`);
        await exec(`echo ${select.value} > ${FILES.refreshStatus}`);
        document.getElementById("previewRefresh").innerText = select.options[select.selectedIndex].text;
    };
}

function setupChipsetMenu() {
    const btn = document.getElementById("btnChipsetMenu");
    const modal = document.getElementById("modalChipset");
    const select = document.getElementById("selectChipset");
    const preview = document.getElementById("previewChipset");
    (async()=>{ let id = (await exec(`cat ${FILES.soc} 2>/dev/null`)).trim() || "1"; preview.innerText = getChipName(id); })();
    btn.onclick = async () => {
        modal.classList.add("active");
        let id = (await exec(`cat ${FILES.soc} 2>/dev/null`)).trim() || "1";
        select.value = id;
    };
    select.onchange = async () => {
        await exec(`echo ${select.value} > ${FILES.soc}`);
        localStorage.setItem("chipset_id", select.value);
        preview.innerText = getChipName(select.value);
        document.getElementById("infoChipsetDisplay").innerText = getChipName(select.value);
    };
}

function setupSelectMenu(btnId, modalId, selectId, displayId, previewId, file, defaultVal) {
    const btn = document.getElementById(btnId);
    const modal = document.getElementById(modalId); 
    const select = document.getElementById(selectId);
    const display = document.getElementById(displayId);
    const preview = document.getElementById(previewId);
    (async()=>{ const val = (await exec(`cat ${file} 2>/dev/null`)).trim() || defaultVal; preview.innerText = val; })();
    btn.onclick = async () => {
        modal.classList.add("active");
        const val = (await exec(`cat ${file} 2>/dev/null`)).trim() || defaultVal;
        select.value = val;
        display.innerText = select.options[select.selectedIndex]?.text || val;
    };
    select.onchange = async () => {
        const val = select.value;
        const txt = select.options[select.selectedIndex].text;
        await exec(`echo "${val}" > ${file}`);
        display.innerText = txt;
        preview.innerText = txt;
    };
}

//  OTHER AGAIN
function initColorBoost() {
    document.getElementById("btnColorMenu").onclick = () => document.getElementById("modalColor").classList.add("active");
    document.getElementById("colorSlider").oninput = async (e) => {
        const v = parseFloat(e.target.value);
        let boost = (v === 0) ? 0.0 : (1.0 + (v - 1) * 0.2);
        document.getElementById("colorVal").innerText = boost.toFixed(2);
        await exec(`service call SurfaceFlinger 1022 f ${boost}`);
        document.getElementById("colorImg").style.filter = (v===0) ? "grayscale(100%)" : `saturate(${boost}) brightness(${boost})`;
    };
}
function setupCpuCtrlMenu() {
    const btn = document.getElementById("btnCpuCtrlMenu");
    const modal = document.getElementById("modalCpuCtrl");
    const cont = document.getElementById("cpuButtons");
    btn.onclick = async () => {
        modal.classList.add("active");
        cont.innerHTML = "Loading...";
        const online = (await exec("cat /sys/devices/system/cpu/cpu*/online")).trim().split("\n");
        cont.innerHTML = "";
        for(let i=0; i<8; i++) {
            const b = document.createElement("button"); b.innerText = `CPU ${i}`;
            const isOn = (online[i] == 1);
            b.style.cssText = `padding:10px;margin:5px;border-radius:8px;border:none;color:white;background:${isOn?"var(--color-green)":"var(--color-red)"}`;
            b.onclick = async () => {
                await exec(`sh ${FILES.scriptCpuCtrl} ${i}`);
                b.style.background = (b.style.background.includes("green")) ? "var(--color-red)" : "var(--color-green)";
            };
            cont.appendChild(b);
        }
    };
}
function setupGovMenu() {
    const btn = document.getElementById("btnGovMenu");
    const modal = document.getElementById("modalGov");
    const select = document.getElementById("selectGov");
    (async()=>{ const cur = (await exec(`cat ${FILES.defaultGov} 2>/dev/null`)).trim(); document.getElementById("previewGov").innerText = cur || "..."; })();
    btn.onclick = async () => {
        modal.classList.add("active");
        const govs = (await exec("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors")).split(" ");
        const cur = (await exec(`cat ${FILES.defaultGov} 2>/dev/null`)).trim();
        select.innerHTML = "";
        govs.forEach(g => { if(!g.trim()) return; const o = document.createElement("option"); o.value=g; o.text=g; if(g===cur) o.selected=true; select.appendChild(o); });
    };
    select.onchange = async () => { await exec(`sh ${FILES.scriptGov} ${select.value}`); document.getElementById("previewGov").innerText = select.value; };
}
function setupLicenseMenu() {
    document.getElementById("btnLicenseMenu").onclick = () => document.getElementById("modalLicense").classList.add("active");
    document.getElementById("btnActivateLicense").onclick = async () => {
        try { await exec(`echo "${document.getElementById("inputLicense").value}" > ${FILES.license}`); alert("Activated!"); } catch { alert("Failed"); }
    };
}
function setupBackupMenu() {
    document.getElementById("btnBackupMenu").onclick = () => document.getElementById("modalBackup").classList.add("active");
    document.getElementById("btnBackup").onclick = async () => {
        const cmd = `te=$(cat ${FILES.thermal}); echo "THERMAL=$te" > ${FILES.backupFile}; cp "${FILES.banner}" "${FILES.backupBg}"`;
        await exec(cmd); alert("Backup Done");
    };
    document.getElementById("btnRestore").onclick = async () => {
        const cmd = `val_te=$(grep "^THERMAL=" ${FILES.backupFile} | cut -d= -f2); echo "$val_te" > ${FILES.thermal}; cp "${FILES.backupBg}" "${FILES.banner}"`;
        await exec(cmd); location.reload();
    };
}

// Banner
async function loadBanner() {
    try { const c=JSON.parse(await exec(`cat ${FILES.bannerConfig} 2>/dev/null`)); bannerConfig=c; } catch {}
    const img = document.getElementById("mainBannerImage");
    img.src = `assets/banner.webp?t=${Date.now()}`;
    document.documentElement.style.setProperty('--banner-darkness', bannerConfig.darkness/100);
    document.documentElement.style.setProperty('--banner-blur', `${bannerConfig.blur}px`);
}
function setupBannerMenu() {
    const btn = document.getElementById("btnOpenBannerModal");
    const modal = document.getElementById("modalBanner");
    const select = document.getElementById("selectBannerFile");
    btn.onclick = async () => {
        modal.classList.add("active");
        select.innerHTML = "<option value='current'>Current</option><option value='restore'>Restore Default</option>";
        try {
            const files = (await exec(`ls "${DOWNLOAD_PATH}" | grep -iE "\\.(jpg|png|webp|gif)$"`)).split("\n");
            files.forEach(f => { if(f) select.innerHTML += `<option value="${DOWNLOAD_PATH}/${f}">${f}</option>`; });
        } catch {}
    };
    const pv = document.getElementById("previewImage");
    select.onchange = async () => {
        const v = select.value;
        if(v==="current") pv.src = `assets/banner.webp?t=${Date.now()}`;
        else if(v==="restore") {
            try { await exec(`cp "${FILES.backup}" "${FILES.tmpPreview}"`); pv.src=`assets/preview_temp?t=${Date.now()}`; } catch {}
        } else {
            await exec(`mkdir -p ${ASSETS_DIR} && cat "${v}" > "${FILES.tmpPreview}" && chmod 644 "${FILES.tmpPreview}"`);
            pv.src = `assets/preview_temp?t=${Date.now()}`;
        }
    };
    document.getElementById("btnSaveBanner").onclick = async () => {
        const v = select.value;
        const d = document.getElementById("rangeDarkness").value;
        const b = document.getElementById("rangeBlur").value;
        if(v==="restore") { await exec(`[ -f "${FILES.backup}" ] && mv -f "${FILES.backup}" "${FILES.banner}"`); bannerConfig={darkness:30,blur:0}; }
        else if(v!=="current") {
            await exec(`[ ! -f "${FILES.backup}" ] && cp "${FILES.banner}" "${FILES.backup}"`);
            await exec(`mv -f "${FILES.tmpPreview}" "${FILES.banner}" && chmod 644 "${FILES.banner}"`);
        }
        bannerConfig.darkness=parseInt(d); bannerConfig.blur=parseInt(b);
        await exec(`echo '${JSON.stringify(bannerConfig)}' > "${FILES.bannerConfig}"`);
        await exec(`rm -f "${FILES.tmpPreview}"`);
        loadBanner(); modal.classList.remove("active");
    };
    document.getElementById("rangeDarkness").oninput=(e)=>document.getElementById("previewOverlay").style.backgroundColor=`rgba(0,0,0,${e.target.value/100})`;
    document.getElementById("rangeBlur").oninput=(e)=>document.getElementById("previewImage").style.filter=`blur(${e.target.value}px)`;
}
