#!/system/bin/sh

RENDER_DIR="/data/local/tmp/RaiRin-AI/render"
MODULE_BIN="/data/local/tmp/RaiRin-AI/render"
RAIRIN_DIR="/data/adb/modules/RaiRin-AI"
STATUS_FILE="$RENDER_DIR/status.txt"
BIN_SKIA="$MODULE_BIN/skia-rec"
BIN_VULKAN="$MODULE_BIN/vulkan-rec"

log_msg() {
    echo "$1"
    log -t "Render-Rec" "$1"
}


if [ ! -f "$STATUS_FILE" ]; then
    log_msg "Error: File $STATUS_FILE not dound."
    exit 1
fi

MODE=$(cat "$STATUS_FILE" | tr -d '[:space:]')

log_msg "Mode detected: $MODE"

if [ "$MODE" == "skia" ]; then
    if [ -f "$BIN_SKIA" ]; then
        log_msg "running Skia Recorder..."
        chmod +x "$BIN_SKIA"
        
        "$BIN_SKIA" 
    
    else
        log_msg "Error: Binary $BIN_SKIA not found."
    fi

elif [ "$MODE" == "vk" ]; then
    if [ -f "$BIN_VULKAN" ]; then
        log_msg "running Vulkan Recorder..."
        chmod +x "$BIN_VULKAN"
        
        "$BIN_VULKAN" 
    else
        log_msg "Error: Binary $BIN_VULKAN not found."
    fi

else
    log_msg "Mode '$MODE' not recognized"
fi
