#!/system/bin/sh


IDX=$1

if [ -z "$IDX" ]; then
  echo "No index provided"
  exit 1
fi

service call SurfaceFlinger 1035 i32 $IDX

echo "Set refresh rate index to $IDX"
exit 0
