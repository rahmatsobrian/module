#!/system/bin/sh
PERF="/data/adb/modules/RaiRin-AI/cortex/thunderclash"
BIN="$PERF/RaiRin-performance"
chmod +x "$BIN"
# Exec 
"$BIN"