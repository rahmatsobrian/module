#!/system/bin/sh
CPU_GOV="/sys/devices/system/cpu/cpu0/cpufreq"
DEST_DIR="/data/local/tmp/thunder_default"
DEST_FILE="$DEST_DIR/governor_default.txt"
DND="$DEST_DIR/dnd.txt"

mkdir -p "$DEST_DIR"

# Simpan governor default
if [ -f "$CPU_GOV/scaling_governor" ]; then
    gov=$(tr '[:upper:]' '[:lower:]' < "$CPU_GOV/scaling_governor")
else
    gov="schedutil"
fi
echo "$gov" > "$DEST_FILE"

get_cpu_name() {
    local codename=""
    # Cek device-tree model
    if [ -f /proc/device-tree/model ]; then
        codename=$(tr -d '\0' < /proc/device-tree/model)
    fi
    # Cek device-tree compatible
    if [ -z "$codename" ] && [ -f /proc/device-tree/compatible ]; then
        codename=$(tr -d '\0' < /proc/device-tree/compatible | cut -d ',' -f1)
    fi
    # Fallback ke metode lama
    if [ -z "$codename" ]; then
        codename=$(getprop ro.soc.model)
        [ -z "$codename" ] && codename=$(getprop ro.soc.manufacturer)
        [ -z "$codename" ] && codename=$(getprop ro.mediatek.platform)
        [ -z "$codename" ] && codename=$(getprop ro.board.platform)
        [ -z "$codename" ] && codename=$(grep -m1 'Hardware' /proc/cpuinfo | cut -d ':' -f2 | sed 's/^[ \t]*//')
    fi
    echo "${codename:-unknown}" | tr '[:upper:]' '[:lower:]'
}

chipset=$(get_cpu_name)

# Default 0
soc_id=0
case "$chipset" in
    *mediatek* | *mt[0-9]* )
        soc_id=1 ;;  # MediaTek
    *qualcomm* | *qcom* | *sm[0-9]* | *sdm* | *msm* | *snapdragon* )
        soc_id=2 ;;  # Qualcomm Snapdragon
    *samsung* | *exynos* | *erd* | *s5e* | *universal* )
        soc_id=3 ;;  # Samsung Exynos
    *unisoc* | *ums* | *sp[0-9]* )
        soc_id=4 ;;  # Unisoc / Spreadtrum
    *google* | *tensor* | *gs[0-9]* )
        soc_id=5 ;;  # Google Tensor
esac

echo "$soc_id" > "$DEST_DIR/soc"
