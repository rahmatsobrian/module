BIN="/data/adb/modules/RaiRin-AI/cortex/cache"
"$BIN/cache"