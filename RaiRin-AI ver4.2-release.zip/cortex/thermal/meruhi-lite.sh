#!/system/bin/sh
MODDIR="/data/adb/modules/RaiRin-AI"
BIN="$MODDIR/cortex/thermal"
"$BIN/lite" 2>/dev/null
 
