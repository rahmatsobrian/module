#!/system/bin/sh
MODDIR="/data/adb/modules/RaiRin-AI"
BIN="$MODDIR/cortex/thermal"
"$BIN/extreme" 2>/dev/null
 
