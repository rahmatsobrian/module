#!/system/bin/sh
MOD_DIR="/data/adb/modules/RaiRin-AI/cortex/thermal"
BIN="$MOD_DIR/backup"
chmod +x "$BIN"
"$BIN" 