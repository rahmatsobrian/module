#!/system/bin/sh
MODDIR="/data/adb/modules/RaiRin-AI"
BIN="$MODDIR/cortex/thermal"
"$BIN/enable" 2>/dev/null
 
