#!/system/bin/sh

for i in $(seq 0 7); do
    cpu="/sys/devices/system/cpu/cpu$i/cpufreq"
    online="/sys/devices/system/cpu/cpu$i/online"
    if [ -f "$cpu/scaling_cur_freq" ]; then
        cur=$(cat $cpu/scaling_cur_freq)
        min=$(cat $cpu/scaling_min_freq)
        max=$(cat $cpu/scaling_max_freq)
        on=$(cat $online 2>/dev/null || echo 1)
        echo "$cur,$min,$max,$on"
    else
        echo "0,1,1,0"
    fi
done