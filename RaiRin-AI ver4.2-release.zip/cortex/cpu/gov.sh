#!/system/bin/sh
DIR="/data/adb/modules/RaiRin-AI/cortex/cpu"
BIN="$DIR/mini-backup"
apply() {
  local value="$1"
  local file="$2"
  [ -f "$file" ] || return 1
  chmod 644 "$file" 2>/dev/null
  echo "$value" >"$file" 2>/dev/null
  chmod 444 "$file" 2>/dev/null
}

chmod +x "$BIN"
GOV="$1"

if [ -z "$GOV" ]; then
  echo "Usage: $0 <governor>"
  exit 1
fi
for CPU_PATH in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
  apply "$GOV" "$CPU_PATH"
done

DEFAULT_FILE="/data/adb/modules/RaiRin-AI/cortex/cpu/default-gov.txt"
apply "$GOV" "$DEFAULT_FILE"
"$BIN"
echo "Setting governor to $GOV, please wait..."
echo "Governor set to $GOV"