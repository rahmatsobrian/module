#!/system/bin/sh
DIR="/data/adb/modules/RaiRin-AI/cortex/cpu"
BIN="$DIR/backup"
chmod +x "$BIN"
"$BIN"