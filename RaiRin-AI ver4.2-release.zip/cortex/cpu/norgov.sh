#!/system/bin/sh

DIR="/data/adb/modules/RaiRin-AI/cortex/cpu"
BIN="$DIR/restore"
TMP_ICON="/data/local/tmp/rairin.webp"

# Fungsi Notifikasi
safe_toast() {
  if [ -x /system/bin/am ]; then
    am start -a android.intent.action.MAIN -e toasttext "$1" -n bellavita.toast/.MainActivity 2>/dev/null &
  fi
}

chmod +x "$BIN"
"$BIN"

# ==========================================
safe_toast "Normal mode Restored"
su -lp 2000 -c "cmd notification post -S bigtext -t 'RaiRin-AI' RaiRin 'Normal Mode Restored'" 2>/dev/null
sleep 1
su -lp 2000 -c "/system/bin/cmd notification post \
    -t 'RaiRin-AI' \
    -i file://$TMP_ICON \
    -I file://$TMP_ICON \
    'RaiRin' 'Normal Mode Restored'" 2>/dev/null


exit 0
