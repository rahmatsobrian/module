#!/system/bin/sh
CPU_PATH="/sys/devices/system/cpu"

toggle_cpu() {
    local cpu="$1"
    local online_file="$CPU_PATH/cpu$cpu/online"

    if [ ! -f "$online_file" ]; then
        echo "CPU$cpu not found"
        return 1
    fi

    chmod 644 "$online_file"

    local val=$(cat "$online_file")
    if [ "$val" -eq 1 ]; then
        echo 0 > "$online_file"
    else
        echo 1 > "$online_file"
    fi

    cat "$online_file"
}

if [ $# -eq 1 ]; then
    toggle_cpu "$1"
else
    echo "Usage: $0 <cpu_index>"
    exit 1
fi