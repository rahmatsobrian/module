#!/system/bin/sh

logfile="/data/adb/modules/RaiRin-AI/vsync.log"
LICENSE_FILE="/data/adb/modules/RaiRin-AI/engine/license.txt"
TMP_LICENSE="/data/local/tmp/license.txt"
MODULE_DIR="/data/adb/modules/RaiRin-AI"
RAIRIN="/data/adb/modules/RaiRin-AI/engine"
TMP="/data/local/tmp/RaiRin-AI"

while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 5
done
sleep 2
echo "=== SCRIPT STARTED $(date) ===" > "$logfile"
if [ -f "/data/adb/modules/RaiRin-AI/permission.sh" ]; then
    echo "> Found permission.sh, executing..." >> "$logfile"
    chmod 0755 "/data/adb/modules/RaiRin-AI/permission.sh"
    chmod 0755 "/data/adb/modules/RaiRin-AI/action.sh"    
    sh /data/adb/modules/RaiRin-AI/permission.sh >> "$logfile" 2>&1    
    echo "> Execution attempt finished." >> "$logfile"
else
    echo "> /data/adb/modules/RaiRin-AI/permission.sh NOT FOUND" >> "$logfile"
fi
if [ -f "/data/adb/modules/RaiRin-AI/cortex/log/save.sh" ]; then
    chmod 0755 "/data/adb/modules/RaiRin-AI/cortex/log/save.sh"
    sh "/data/adb/modules/RaiRin-AI/cortex/log/save.sh"
fi
[ -f "/data/adb/modules/RaiRin-AI/cortex/soc/soc.sh" ] && sh "/data/adb/modules/RaiRin-AI/cortex/soc/soc.sh"
[ -f "/data/local/tmp/RaiRin-AI/kernel_panic.sh" ] && sh /data/local/tmp/RaiRin-AI/kernel_panic.sh
[ -f "/data/adb/modules/RaiRin-AI/cortex/cpu/backup.sh" ] && sh /data/adb/modules/RaiRin-AI/cortex/cpu/backup.sh
[ -f "/data/adb/modules/RaiRin-AI/cortex/thermal/kaname.sh" ] && sh /data/adb/modules/RaiRin-AI/cortex/thermal/kaname.sh
echo "Default" > "/data/adb/modules/RaiRin-AI/cortex/net/booster.txt"
echo "enabled" > "/data/local/tmp/RaiRin-AI/log_option.txt"
echo "disabled" > "/data/adb/modules/RaiRin-AI/cortex/dex2oat/status.txt"
if [ -s "$TMP_LICENSE" ]; then
    cp "$TMP_LICENSE" "$LICENSE_FILE"
fi
sleep 5
cmd power set-fixed-performance-mode-enabled true 2>/dev/null
if [ -f "$TMP/RaiRin-Boost" ]; then
    chmod 0755 "$TMP/RaiRin-Boost"
    "$TMP/RaiRin-Boost"
fi
run_bg() {
    local bin="/data/adb/modules/RaiRin-AI/engine/$1"
    if [ -f "$bin" ]; then
        chmod 0755 "$bin"
        nohup "$bin" >/dev/null 2>&1 &
    fi
}
run_bg "RaiRin-game"
run_bg "RaiRin-bat"
run_bg "RaiRin-thermal"
run_bg "RaiRin-bypass"
sleep 5
run_bg "RaiRin-main"
sleep 50
run_bg "Rin-perf"
