#
# Copyright (C) 2024-2025 Zexshia
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

SKIPUNZIP=1

ui_print "- unziping service.sh..."
unzip -o "$ZIPFILE" service.sh -d "$MODPATH"
ui_print "- unziping module.prop..."
unzip -o "$ZIPFILE" module.prop -d "$MODPATH"
ui_print "- unziping uninstall.sh..."
unzip -o "$ZIPFILE" uninstall.sh -d "$MODPATH"
ui_print "- unziping banner.png..."
unzip -o "$ZIPFILE" banner.png -d "$MODPATH"
ui_print "- Extracting system directory..."
unzip -o "$ZIPFILE" 'system/bin/perlica' -d "$MODPATH"

# Use Symlink
if [ "$KSU" = "true" ] || [ "$APATCH" = "true" ]; then
    # skip mount on APatch / KernelSU
    touch "$MODPATH/skip_mount"
    ui_print "- KSU/AP Detected, skipping module mount (skip_mount)"
    # symlink ourselves on $PATH
    manager_paths="/data/adb/ap/bin /data/adb/ksu/bin"
    BIN_PATH="/data/adb/modules/vsync120/system/bin"
    for dir in $manager_paths; do
        [ -d "$dir" ] && {
            ui_print "- Creating symlink in $dir"
            ln -sf "$BIN_PATH/perlica" "$dir/perlica"
        }
    done
fi

# Set Permissions
ui_print "- Setting Permissions..."
set_perm_recursive "$MODPATH/system/bin" 0 2000 0777 0777
chmod +x "$MODPATH/system/bin/perlica"

ui_print "- Installation complete!"
