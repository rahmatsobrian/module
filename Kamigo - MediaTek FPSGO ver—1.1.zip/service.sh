#!/system/bin/sh
KAMIGO_BIN="/data/adb/modules/kamigo/bin"
run() {
    local script_name="$1"
    local shell_path="$KAMIGO_BIN/$script_name"    
    if [ -f "$shell_path" ]; then
        chmod +x "$shell_path"
        "$shell_path"
    fi
    sleep 1
}

while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 5
done
sleep 30
run "check.sh"
run "fpsgo.sh"
exit 0