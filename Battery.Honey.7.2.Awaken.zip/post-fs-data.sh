#!/system/bin/sh

MODDIR="/data/adb/modules/batteryhoney"
SERVICE="$MODDIR/service.sh"

chmod 0755 "$SERVICE"
