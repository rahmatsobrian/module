#!/system/bin/sh

TTL=65

sysctl -w net.ipv4.ip_default_ttl=$TTL

for IFACE in $(sysctl -a 2>/dev/null | grep -Eo '^net\.ipv6\.conf\.[^\.]+\.hop_limit'); do
    sysctl -w $IFACE=$TTL
done