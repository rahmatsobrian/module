#!/system/bin/sh
ui_print "- Installing TTL 65"