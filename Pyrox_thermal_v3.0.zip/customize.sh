ui_print "******************************"
ui_print " Overheat and fire ahead"
ui_print " Developer doesn't account for any damages"
ui_print " from using this module, use it on your own risk."
ui_print "******************************"

rm "$MODPATH/LICENSE"
