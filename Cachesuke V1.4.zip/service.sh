#!/system/bin/sh

BIN="/system/bin"
DAEMON="$BIN/cachesuke-daemon"
MANGEKYOU="$BIN/cachesuke-daemon-loop"
LOG_FILE="/data/adb/modules/Cachesuke/daemon.log"
SCRIPT="/data/adb/modules/Cachesuke"
log() {
    echo "[cachesuke] $1" >> "$LOG_FILE"
    tail -n 20 "$LOG_FILE" > "$LOG_FILE.tmp" && mv "$LOG_FILE.tmp" "$LOG_FILE"
}

# ====== Wait Boot ======
while [ -z "$(getprop sys.boot_completed)" ]; do
    sleep 5
done
chmod +x "$SCRIPT/action.sh"
chmod +x "$SCRIPT/stop.sh"
chmod +x "$SCRIPT/clear.sh"
# Jalankan cachesuke-daemon
if [ -x "$DAEMON" ]; then
    nohup "$DAEMON" >/dev/null 2>&1 &
    log "running daemon"
else
    log "ERROR: $DAEMON tidak ditemukan atau tidak executable"
fi

# Jalankan mangekyou
if [ -x "$MANGEKYOU" ]; then
    nohup "$MANGEKYOU" >/dev/null 2>&1 &
    log "running mangekyou"
else
    log "ERROR: $MANGEKYOU tidak ditemukan atau tidak executable"
fi