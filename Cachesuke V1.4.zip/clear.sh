#!/system/bin/sh
PROP="/data/adb/modules/Cachesuke/module.prop"
PID=$(pidof /system/bin/cachesuke-daemon)
WHITELIST_FILE="/data/adb/modules/Cachesuke/whitelist.txt"
WHITELIST=()
[ -f "$WHITELIST_FILE" ] && while IFS= read -r w; do
    [ -z "$w" ] && continue
    case "$w" in \#*) continue ;; esac
    WHITELIST+=("$w")
done < "$WHITELIST_FILE"
is_whitelisted() {
    local pkg="$1"
    for w in "${WHITELIST[@]}"; do
        [ "$pkg" = "$w" ] && return 0
    done
    return 1
}
clean_cache_for_app() {
    local app_dir="$1"
    local pkg=$(basename "$app_dir")
    is_whitelisted "$pkg" && return
    local cache_dir="$app_dir/cache"
    if [ -d "$cache_dir" ]; then
        echo "Attacking cache with Mangekyou Sharingan: $pkg"
        rm -rf "$cache_dir" >/dev/null 2>&1
    fi
}
for app_dir in /data/data/*; do
    [ -d "$app_dir" ] && clean_cache_for_app "$app_dir"
done
for app_dir in /data/media/0/Android/data/*; do
    [ -d "$app_dir" ] && clean_cache_for_app "$app_dir"
done

echo "Finished trim cache (whitelist excluded)."
# Status
# default fields
BASE_ID="id=Cachesuke"
BASE_NAME="name=Cachesuke—加守助"
BASE_VERSION="version=v1.4—release"
BASE_VERSIONCODE="versionCode=1"
BASE_AUTHOR="author=kaminarich"
BASE_BANNER="banner=webroot/assets/ban.webp"

# ambil description yang ada, kalau gak ada pakai default
if [ -f "$PROP" ]; then
  CUR_DESC_LINE="$(grep -m1 '^description=' "$PROP" 2>/dev/null || true)"
  if [ -n "$CUR_DESC_LINE" ]; then
    CUR_DESC="${CUR_DESC_LINE#description=}"
    # hapus bila sudah ada " | Daemon Status: ..."
    CLEAN_DESC="$(printf '%s' "$CUR_DESC" | sed 's/ *| *Daemon Status: .*//')"
  else
    CLEAN_DESC="Auto clear your Apps Cache | Set Interval on WebUI"
  fi
else
  CLEAN_DESC="Auto clear your Apps Cache | Set Interval on WebUI"
fi

if [ -n "$PID" ]; then
  STATUS="Online 🟢"
else
  STATUS="Offline 🔴"
fi

NEW_DESC="description=${CLEAN_DESC} | Daemon Status: ${STATUS}"

# tulis ulang module.prop dengan description yang sudah di-append status
cat > "$PROP" <<EOF
$BASE_ID
$BASE_NAME
$BASE_VERSION
$BASE_VERSIONCODE
$BASE_AUTHOR
$NEW_DESC
$BASE_BANNER
EOF