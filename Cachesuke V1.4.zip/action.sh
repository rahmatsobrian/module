#!/system/bin/sh

BIN="/system/bin"
DAEMON="$BIN/cachesuke-daemon"
MANGEKYOU="$BIN/cachesuke-daemon-loop"
LOG_FILE="/data/adb/modules/Cachesuke/daemon.log"
SCRIPT="/data/adb/modules/Cachesuke"
log() {
    echo "[cachesuke] $1" >> "$LOG_FILE"
    tail -n 20 "$LOG_FILE" > "$LOG_FILE.tmp" && mv "$LOG_FILE.tmp" "$LOG_FILE"
}


pkill -f cachesuke-daemon-loop
sleep 1
pkill -f cachesuke-daemon
sleep 1
if [ -x "$DAEMON" ]; then
    nohup "$DAEMON" >/dev/null 2>&1 &
    log "running daemon"
else
    log "ERROR: $DAEMON tidak ditemukan atau tidak executable"
fi

# Jalankan mangekyou
if [ -x "$MANGEKYOU" ]; then
    nohup "$MANGEKYOU" >/dev/null 2>&1 &
    log "running mangekyou"
else
    log "ERROR: $MANGEKYOU tidak ditemukan atau tidak executable"
fi