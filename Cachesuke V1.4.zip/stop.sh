#!/system/bin/sh
pkill -f cachesuke-daemon-loop
sleep 1
pkill -f cachesuke-daemon
#!/system/bin/sh

PROP="/data/adb/modules/Cachesuke/module.prop"
PID="$(pidof /system/bin/cachesuke-daemon 2>/dev/null)"

# default fields
BASE_ID="id=Cachesuke"
BASE_NAME="name=Cachesuke—加守助"
BASE_VERSION="version=v1.4—release"
BASE_VERSIONCODE="versionCode=1"
BASE_AUTHOR="author=kaminarich"
BASE_BANNER="banner=webroot/assets/ban.webp"

# ambil description yang ada, kalau gak ada pakai default
if [ -f "$PROP" ]; then
  CUR_DESC_LINE="$(grep -m1 '^description=' "$PROP" 2>/dev/null || true)"
  if [ -n "$CUR_DESC_LINE" ]; then
    CUR_DESC="${CUR_DESC_LINE#description=}"
    # hapus bila sudah ada " | Daemon Status: ..."
    CLEAN_DESC="$(printf '%s' "$CUR_DESC" | sed 's/ *| *Daemon Status: .*//')"
  else
    CLEAN_DESC="Auto clear your Apps Cache | Set Interval on WebUI"
  fi
else
  CLEAN_DESC="Auto clear your Apps Cache | Set Interval on WebUI"
fi

if [ -n "$PID" ]; then
  STATUS="Online 🟢"
else
  STATUS="Offline 🔴"
fi

NEW_DESC="description=${CLEAN_DESC} | Daemon Status: ${STATUS}"

# tulis ulang module.prop dengan description yang sudah di-append status
cat > "$PROP" <<EOF
$BASE_ID
$BASE_NAME
$BASE_VERSION
$BASE_VERSIONCODE
$BASE_AUTHOR
$NEW_DESC
$BASE_BANNER
EOF