#!/system/bin/sh
MODULE_DIR="/data/adb/modules/POW"
SERVICE="$MODULE_DIR/service.sh"

if [ -f "$SERVICE" ]; then
chmod 0755 "$SERVICE"    
fi
