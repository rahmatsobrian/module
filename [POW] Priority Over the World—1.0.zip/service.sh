#!/system/bin/sh

MODULE_DIR="/data/adb/modules/POW"
BIN="$MODULE_DIR/bin"

while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 5
done
sleep 10


if [ -f "$BIN/pow-daemon" ]; then
    chmod 0755 "$BIN/pow-daemon" 2>/dev/null
    [ -f "$BIN/pow" ] && chmod 0755 "$BIN/pow" 2>/dev/null
    nohup "$BIN/pow-daemon" >/dev/null 2>&1 &
  else
    exit 0
fi