#!/system/bin/sh
# ===============================================
# POW Module Installer Script
# ===============================================

SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE=""

MODPATH="${MODPATH:-/data/adb/modules/POW}"

info_print() {
  if [ -f "$MODPATH/banner" ]; then
    awk '{print}' "$MODPATH/banner"
  fi
  ui_print ""
  sleep 2
  ui_print "Made by : kaminarich | @kaminarich_here"
  sleep 5
  ui_print ""
}

on_install() {
  ui_print " "


  unzip -o "$ZIPFILE" 'banner' -d "$MODPATH" >&2
  info_print

  ui_print "> Merging into reality ..."
  sleep 2


  unzip -o "$ZIPFILE" 'post-fs-data.sh' -d "$MODPATH" >&2
  unzip -o "$ZIPFILE" 'service.sh' -d "$MODPATH" >&2
  unzip -o "$ZIPFILE" 'bin/*' -d "$MODPATH" >&2
  unzip -o "$ZIPFILE" 'webroot/*' -d "$MODPATH" >&2
  unzip -o "$ZIPFILE" 'gamelist.txt' -d "$MODPATH" >&2

  ui_print " "
}

set_permissions() {
  set_perm_recursive "$MODPATH" 0 0 0755 0755
  set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
}
