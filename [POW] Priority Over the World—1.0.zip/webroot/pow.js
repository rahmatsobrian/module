const MODULE_PATH = "/data/adb/modules/POW";
const GAME_FILE = `${MODULE_PATH}/gamelist.txt`;
const DAEMON_NAME = "pow-daemon";
const PROP_FILE = `${MODULE_PATH}/module.prop`;

function exec(command) {
  return new Promise((resolve, reject) => {
    const cb = `exec_cb_${Date.now()}`;
    window[cb] = (errno, stdout, stderr) => {
      delete window[cb];
      if (errno !== 0) reject(new Error(stderr || stdout || "Exec failed"));
      else resolve(stdout.trim());
    };
    try { ksu.exec(command, `window.${cb}`); }
    catch (e) { reject(e); }
  });
}

// === Helper open link via am start ===
async function openLink(url) {
  try {
    await exec(`am start -a android.intent.action.VIEW -d "${url}"`);
  } catch (err) {
    console.error("openLink failed:", err);
    alert("Failed to open link: " + url);
  }
}

// === Load System Info ===
async function loadInfo() {
  try {
    const version = await exec(`grep -m1 '^version=' ${PROP_FILE} | cut -d= -f2 || echo Unknown`);
    const kernel = await exec("uname -r || echo N/A");
    const sdk = await exec("getprop ro.build.version.sdk || echo N/A");
    document.getElementById("version").textContent = version;
    document.getElementById("kernel").textContent = kernel;
    document.getElementById("sdk").textContent = sdk;
  } catch {
    ["version","kernel","sdk"].forEach(id => document.getElementById(id).textContent = "Error");
  }
}

// === Load PID ===
async function loadPID() {
  try {
    const pid = await exec(`pidof ${DAEMON_NAME} 2>/dev/null || echo -`);
    document.getElementById("pid").textContent = pid;
  } catch {
    document.getElementById("pid").textContent = "Error";
  }
}

// === Gamelist ===
let allApps = [];
let savedGames = [];

async function loadApps() {
  const listEl = document.getElementById("gamelist");
  const status = document.getElementById("gamelist-status");
  const search = document.getElementById("gamelist-search");
  listEl.innerHTML = `<div class="loading">Loading...</div>`;

  try {
    const savedRaw = await exec(`[ -f ${GAME_FILE} ] && cat ${GAME_FILE} || echo ""`);
    savedGames = savedRaw.split(/\r?\n/).filter(Boolean);

    const pkgsRaw = await exec("pm list packages -3 || true");
    allApps = pkgsRaw.split(/\r?\n/).map(l => l.replace("package:", "").trim()).filter(Boolean);

    renderAppList(search.value || "");
    status.textContent = `${savedGames.length} saved • ${allApps.length} installed`;
  } catch (e) {
    console.error("Load apps failed:", e);
    listEl.innerHTML = `<div class="loading">Failed to load apps</div>`;
  }
}

function renderAppList(filter = "") {
  const listEl = document.getElementById("gamelist");
  const q = filter.toLowerCase();
  listEl.innerHTML = "";

  const makeItem = (pkg, isSaved) => {
    const div = document.createElement("div");
    div.className = "gamelist-item" + (isSaved ? " saved" : "");
    div.textContent = (isSaved ? "⭐ " : "") + pkg;
    div.onclick = () => saveGame(pkg);
    return div;
  };

  // Saved games
  savedGames.forEach(pkg => {
    if (!pkg.toLowerCase().includes(q)) return;
    listEl.appendChild(makeItem(pkg, true));
  });

  // Apps lain
  allApps.forEach(pkg => {
    if (savedGames.includes(pkg)) return;
    if (q && !pkg.toLowerCase().includes(q)) return;
    listEl.appendChild(makeItem(pkg, false));
  });

  if (!listEl.children.length) {
    listEl.innerHTML = `<div class="loading">No results</div>`;
  }
}

async function saveGame(pkg) {
  const status = document.getElementById("gamelist-status");
  if (!pkg) {
    status.textContent = "No app selected.";
    return;
  }

  try {
    const exists = await exec(`[ -f ${GAME_FILE} ] && grep -qx "${pkg}" ${GAME_FILE} && echo 1 || echo 0`);
    if (exists.trim() === "0") {
      await exec(`echo "${pkg}" >> ${GAME_FILE}`);
      savedGames.push(pkg);
      status.textContent = `Added: ${pkg}`;
    } else {
      status.textContent = `Already exists: ${pkg}`;
    }
    renderAppList(document.getElementById("gamelist-search").value);
  } catch (e) {
    status.textContent = `Error: ${e.message}`;
  }
}

async function clearSaved() {
  try {
    await exec(`[ -f ${GAME_FILE} ] && rm -f ${GAME_FILE} || true`);
    savedGames = [];
    renderAppList(document.getElementById("gamelist-search").value);
    document.getElementById("gamelist-status").textContent = "Cleared saved.";
  } catch (e) {
    document.getElementById("gamelist-status").textContent = `Error clearing: ${e.message}`;
  }
}

// === Init ===
document.addEventListener("DOMContentLoaded", async () => {
  await Promise.all([loadPID(), loadInfo(), loadApps()]);

  const search = document.getElementById("gamelist-search");
  search.style.display = "block";
  search.placeholder = "🔍 Search app or saved game...";
  search.addEventListener("input", () => renderAppList(search.value));

  // Tombol Donate → pakai openLink
  const donateBtn = document.getElementById("donate-button");
  donateBtn.addEventListener("click", () => openLink("https://t.me/Kaminarich_HeavenlyArchive/328"));

  // Tombol lainnya
  document.getElementById("refresh-list")?.addEventListener("click", loadApps);
  document.getElementById("clear-saved")?.addEventListener("click", clearSaved);
});