#!/system/bin/sh

CLEAN_SCRIPT="/data/adb/modules/armpit/core/clear.sh"
TMP="/data/local/tmp/armpit/tempstate"

type_echo() {
    text="$1"
    for i in $(seq 1 ${#text}); do
        printf "%s" "${text:$((i-1)):1}"
        sleep 0.03
    done
    printf "\n"
}

echo "======================================="
type_echo "Running cache cleaner..."
if [ -f "$CLEAN_SCRIPT" ]; then
    "$CLEAN_SCRIPT"
    type_echo "Cache successfully cleaned!"
else
    type_echo "clean.sh not found at $CLEAN_SCRIPT"
fi
echo "======================================="
