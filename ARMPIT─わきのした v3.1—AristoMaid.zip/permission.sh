#!/system/bin/sh
MODULE_DIR="/data/adb/modules/armpit"
ARMPIT="$MODULE_DIR/core"
TMP_ICON="/data/local/tmp/rairin.webp"
TMP="/data/local/tmp/RaiRin-AI"

find "$ARMPIT" -type f ! -name "*.txt" -exec chmod 0755 {} \;
