// ============ Konstanta Path ============
const MODE_FILE = "/data/adb/modules/armpit/core/mode.txt";
const BALANCE_SCRIPT = "/data/adb/modules/armpit/core/balance_oriented";
const POWERSAVE_SCRIPT = "/data/adb/modules/armpit/core/battery_oriented";
const PERFORMANCE_SCRIPT = "/data/adb/modules/armpit/core/performance_oriented";
const DEFAULT_SCRIPT = "/data/adb/modules/armpit/core/restore";
const MODULE_PROP = "/data/adb/modules/armpit/module.prop";
const LOG_FILE = "/data/adb/modules/armpit/webroot/logs/log.txt";

// ============ Wrapper exec KSU ============
function exec(command) {
  return new Promise((resolve, reject) => {
    const cb = `exec_cb_${Date.now()}`;
    window[cb] = (errno, stdout, stderr) => {
      delete window[cb];
      if (errno !== 0) reject(new Error(stderr || stdout || "Unknown error"));
      else resolve(stdout);
    };
    try {
      ksu.exec(command, `window.${cb}`);
    } catch (e) {
      reject(e);
    }
  });
}

// ============ Baca File Helper ============
async function readFile(path) {
  try {
    return await exec(`cat ${path}`);
  } catch {
    return "Unavailable";
  }
}

// ============ Load Info ============
function truncate(str, max = 25) {
  return str.length > max ? str.slice(0, max) + "..." : str;
}

async function loadInfo() {
  const modVerEl = document.getElementById("modVer");
  const ndkVerEl = document.getElementById("ndkVer");
  const kernelVerEl = document.getElementById("kernelVer");
  const statusEl = document.getElementById("status");
  const maintainerEl = document.getElementById("maintaner");

  try {
    const moduleProp = await readFile(MODULE_PROP);
    const versionLine = moduleProp.split("\n").find(l => l.startsWith("version=")) || "";
    const version = versionLine.replace("version=", "").trim();

    const ndk = await exec("getprop ro.product.cpu.abi");
    const kernel = await exec("uname -r");
    const mode = await readFile(MODE_FILE);

    modVerEl.textContent = truncate(version);
    ndkVerEl.textContent = truncate(ndk);
    kernelVerEl.textContent = truncate(kernel);
    statusEl.textContent = truncate(mode);
    maintainerEl.textContent = truncate("kaminarich");
  } catch (err) {
    console.error("loadInfo failed:", err);
  }
}

const RAI_FILE = "/data/adb/modules/armpit/webroot/logs/RaiRin.txt";

async function loadRaiRinStatus() {
  const row = document.getElementById("rairinRow");
  const status = document.getElementById("rairinStatus");

  try {
    const content = (await readFile(RAI_FILE)).trim().toLowerCase();
    if (content.includes("on")) {
      row.style.display = "flex";
      status.textContent = "Sync";
      status.style.color = "#7ed6ff";
    } else {
      row.style.display = "none";
    }
  } catch {
    row.style.display = "none";
  }
}

// ============ Load Log (Realtime) ============
let lastLogCache = "";

async function loadLog() {
  const logBox = document.getElementById("logContent");
  try {
    const log = await exec(`tail -n 50 ${LOG_FILE}`);
    if (log !== lastLogCache) {
      lastLogCache = log;
      logBox.textContent = log || "(empty)";
      if (logBox.scrollHeight - logBox.scrollTop - logBox.clientHeight < 30) {
        logBox.scrollTop = logBox.scrollHeight;
      }
    }
  } catch {
    logBox.textContent = "Log unavailable";
  }
}

// ============ Mode Switch ============
function setupSwitches() {
  const switches = {
    balanceSwitch: { path: BALANCE_SCRIPT, label: "Balance" },
    powersaveSwitch: { path: POWERSAVE_SCRIPT, label: "Powersave" },
    performanceSwitch: { path: PERFORMANCE_SCRIPT, label: "Performance" },
    defaultSwitch: { path: DEFAULT_SCRIPT, label: "Default" }
  };

  Object.keys(switches).forEach(id => {
    const sw = document.getElementById(id);
    sw.addEventListener("change", async () => {
      if (sw.checked) {
        Object.keys(switches).forEach(other => {
          if (other !== id) document.getElementById(other).checked = false;
        });

        const selected = switches[id];
        try {
          await exec(`chmod 755 ${selected.path}`);
          await exec(`${selected.path}`);
          await exec(`echo "${selected.label}" > ${MODE_FILE}`);
          document.getElementById("status").textContent = selected.label;
          console.log(`[Armpit] Mode changed to ${selected.label}`);
        } catch (err) {
          console.error("Mode switch failed:", err);
        }
      } else {
        sw.checked = true;
      }
    });
  });
}
// ======== Extras - Default Governor (auto apply) ========
const GOV_FILE = "/data/adb/modules/armpit/core/default-gov.txt";
const GOV_FILE2 = "/data/adb/modules/RaiRin-AI/cortex/cpu/default-gov.txt";
const GOV_SCRIPT = "/data/adb/modules/armpit/core/gov";
const govSelect = document.getElementById("govSelect");
const govOutput = document.getElementById("govOutput");

async function fileExists(path) {
  try { await exec(`test -f ${path}`); return true; }
  catch { return false; }
}

async function getActiveGovFile() {
  return (await fileExists(GOV_FILE2)) ? GOV_FILE2 : GOV_FILE;
}

async function loadGov() {
  try {
    const activeFile = await getActiveGovFile();
    const currentGov = (await readFile(activeFile)).trim() || "Unknown";
    const available = await exec("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors");
    const list = available.trim().split(/\s+/);
    govSelect.innerHTML = "";
    list.forEach(gov => {
      const opt = document.createElement("option");
      opt.value = gov;
      opt.textContent = gov;
      if (gov === currentGov) opt.selected = true;
      govSelect.appendChild(opt);
    });
    govOutput.textContent = `Current: ${currentGov}`;
  } catch (err) {
    console.error("[Governor] loadGov failed:", err);
    govSelect.innerHTML = "<option>Error</option>";
    govOutput.textContent = "Failed to load governor";
  }
}

// Auto apply ketika dropdown diubah
govSelect.addEventListener("change", async () => {
  const selected = govSelect.value;
  if (!selected) return;
  try {
    const activeFile = await getActiveGovFile();
    await exec(`echo "${selected}" > ${activeFile}`);
    await exec(`${GOV_SCRIPT}`);
    govOutput.textContent = `Applied: ${selected}`;
    setTimeout(loadGov, 1500);
  } catch (err) {
    govOutput.textContent = `Failed: ${err.message}`;
  }
});

// ======== Extras - ZRAM (auto apply) ========
const ZRAM_FILE = "/data/adb/modules/armpit/core/zram.txt";
const ZRAM_SCRIPT = "/data/adb/modules/armpit/core/zram";
const zramType = document.getElementById("zramType");
const zramSize = document.getElementById("zramSize");
const zramOutput = document.getElementById("zramOutput");

async function loadZram() {
  try {
    const current = (await readFile(ZRAM_FILE)).trim();
    let type = "", size = "";
    if (current) [type, size] = current.split(/\s+/);

    const compRaw = await exec("cat /sys/block/zram0/comp_algorithm");
    const matches = compRaw.trim().split(/\s+/);
    let currentType = "";
    const availableTypes = matches.map(t => {
      if (t.startsWith("[") && t.endsWith("]")) {
        currentType = t.slice(1, -1);
        return currentType;
      } else return t;
    });

    zramType.innerHTML = "";
    availableTypes.forEach(t => {
      const opt = document.createElement("option");
      opt.value = t;
      opt.textContent = t;
      if (t === type || t === currentType) opt.selected = true;
      zramType.appendChild(opt);
    });

    const memInfo = await exec("cat /proc/meminfo | grep MemTotal");
    const memKB = parseInt(memInfo.match(/\d+/)[0], 10);
    const memMB = Math.floor(memKB / 1024);
    const maxGB = Math.floor(memMB / 1024);

    zramSize.innerHTML = "";
    for (let i = 1; i <= maxGB; i++) {
      const opt = document.createElement("option");
      const valMB = i * 1024;
      opt.value = valMB;
      opt.textContent = `${i}GB`;
      if (valMB == size) opt.selected = true;
      zramSize.appendChild(opt);
    }

    zramOutput.textContent = current ? `Current: ${type || currentType} ${size || "?"}MB` : "Not set";
  } catch (err) {
    console.error("loadZram failed:", err);
    zramOutput.textContent = "Failed to load ZRAM";
  }
}

// Auto apply ZRAM ketika dropdown diubah
async function applyZram() {
  const type = zramType.value;
  const sizeMB = parseInt(zramSize.value, 10);
  if (!type || !sizeMB) return (zramOutput.textContent = "Invalid input");
  try {
    await exec(`echo "${type} ${sizeMB}" > ${ZRAM_FILE}`);
    await exec(`${ZRAM_SCRIPT}`);
    zramOutput.textContent = `Applied: ${type} ${sizeMB}MB`;
  } catch (err) {
    zramOutput.textContent = `Failed: ${err.message}`;
  }
}
zramType.addEventListener("change", applyZram);
zramSize.addEventListener("change", applyZram);

// ======== Extras - Banner (auto apply + video autoplay support) ========
const BANNER_FILE = "/data/adb/modules/armpit/webroot/assets/bg.webp";
const BANNER_VIDEO = "/data/adb/modules/armpit/webroot/assets/bg.mp4";
const bannerSelect = document.getElementById("bannerSelect");
const bannerOutput = document.getElementById("bannerOutput");

async function loadBannerOptions() {
  try {
    const files = await exec(
      'ls /storage/emulated/0/Download/ | grep -E "\\.(jpg|jpeg|png|webp|mp4)$"'
    );
    const list = files.trim().split("\n").filter(Boolean);
    bannerSelect.innerHTML = "";
    list.forEach(f => {
      const opt = document.createElement("option");
      opt.value = f;
      opt.textContent = f;
      bannerSelect.appendChild(opt);
    });
    if (!list.length) bannerSelect.innerHTML = "<option>No media found</option>";
  } catch {
    bannerSelect.innerHTML = "<option>Error loading</option>";
  }
}

// Auto apply banner ketika dropdown diubah
bannerSelect.addEventListener("change", async () => {
  const selected = bannerSelect.value;
  if (!selected) return;

  try {
    if (selected.match(/\.(mp4)$/i)) {
      // File video
      await exec(`rm -f "${BANNER_FILE}" 2>/dev/null || true`);
      await exec(`cp "/storage/emulated/0/Download/${selected}" "${BANNER_VIDEO}"`);
      await exec(`chmod 0644 "${BANNER_VIDEO}"`);
      bannerOutput.textContent = `🎥 Video banner applied: ${selected}`;
    } else {
      // File gambar
      await exec(`rm -f "${BANNER_VIDEO}" 2>/dev/null || true`);
      await exec(`cp "/storage/emulated/0/Download/${selected}" "${BANNER_FILE}"`);
      await exec(`chmod 0644 "${BANNER_FILE}"`);
      bannerOutput.textContent = `🖼️ Image banner applied: ${selected}`;
    }

    await checkBannerMedia();
  } catch (err) {
    console.error("[Banner] apply failed:", err);
    bannerOutput.textContent = `Failed: ${err.message}`;
  }
});

async function checkBannerMedia() {
  try {
    const video = document.getElementById("bannerVideo");
    const img = document.getElementById("bannerImage");

    const hasVideo = (await exec(`[ -s "${BANNER_VIDEO}" ] && echo 1 || echo 0`)).trim() === "1";
    const hasImage = (await exec(`[ -s "${BANNER_FILE}" ] && echo 1 || echo 0`)).trim() === "1";

    if (hasVideo) {
      // Video mode
      img.style.display = "none";
      video.style.display = "block";

      video.muted = true;
      video.loop = true;
      video.autoplay = true;
      video.playsInline = true;
      video.preload = "auto";

      video.load();

      const playPromise = video.play();
      if (playPromise !== undefined) {
        playPromise.then(() => {
          console.log("[Banner] ✅ Video autoplay started");
        }).catch(err => {
          console.warn("[Banner] ⚠️ Autoplay blocked:", err);
          video.controls = true; // tampilkan tombol manual
        });
      }
    } else if (hasImage) {
      // Image mode
      video.pause();
      video.removeAttribute("src");
      video.load();

      video.style.display = "none";
      img.style.display = "block";

      const ts = Date.now();
      img.src = `assets/bg.webp?ts=${ts}`; // refresh cache
    } else {
      // fallback
      video.style.display = "none";
      img.style.display = "none";
    }
  } catch (e) {
    console.error("[Banner] checkBannerMedia failed:", e);
  }
}

document.addEventListener("DOMContentLoaded", () => {
  loadBannerOptions();
  checkBannerMedia();
});

// ============ Sync switches from file ============
async function syncSwitchFromFile() {
  try {
    const mode = await readFile(MODE_FILE);
    const current = mode.trim().toLowerCase();
    const ids = {
      balance: "balanceSwitch",
      powersave: "powersaveSwitch",
      performance: "performanceSwitch",
      default: "defaultSwitch"
    };
    Object.keys(ids).forEach(key => {
      const el = document.getElementById(ids[key]);
      el.checked = current === key;
    });
  } catch (err) {
    console.error("syncSwitchFromFile failed:", err);
  }
}

// === Collapsible ===
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".collapsible").forEach(header => {
    header.addEventListener("click", () => {
      const content = header.nextElementSibling;
      content.classList.toggle("active");
    });
  });
});

// === Info link ===
function setupInfoLinks() {
  const maintainerEl = document.getElementById("maintaner");
  const versionEl = document.getElementById("modVer");

  const openTelegram = async () => {
    try {
      await exec(`am start -a android.intent.action.VIEW -d "https://t.me/kaminarich_here"`);
    } catch (err) {
      console.error("[InfoLinks] Failed:", err);
    }
  };

  [maintainerEl, versionEl].forEach(el => {
    el.style.cursor = "pointer";
    el.style.textDecoration = "underline dotted";
    el.title = "Open Telegram @kaminarich_here";
    el.addEventListener("click", openTelegram);
  });
}
// debloat 
const debloatToggle = document.getElementById("debloatToggle");
const debloatPanel = document.getElementById("debloatPanel");
const appsList = document.getElementById("appsList");
const uninstallBtn = document.getElementById("uninstallBtn");
const uninstallOutput = document.getElementById("uninstallOutput");
const showUserApps = document.getElementById("showUserApps");
const showSystemApps = document.getElementById("showSystemApps");
const searchApp = document.getElementById("searchApp");

const VALID_FILE = "/data/adb/modules/armpit/webroot/assets/valid.txt";
const LICENSE_FILE = "/data/adb/modules/armpit/webroot/assets/license.txt";

let allApps = [];

// 🔍 Tombol utama → cek valid.txt dulu + toggle show/hide
debloatToggle.addEventListener("click", async () => {
  try {
    const valid = await exec(`if [ -f "${VALID_FILE}" ]; then echo 1; else echo 0; fi`);
    const licenseSection = document.getElementById("licenseSection");

    // Kalau belum valid → tampil input lisensi
    if (valid.trim() !== "1") {
      debloatPanel.style.display = "none";
      licenseSection.style.display = "flex";
      debloatToggle.textContent = "Show Apps";
      return;
    }

    // Kalau sudah valid → toggle panel
    licenseSection.style.display = "none";
    if (debloatPanel.style.display === "flex") {
      debloatPanel.style.display = "none";
      debloatToggle.textContent = "Show Apps";
    } else {
      debloatPanel.style.display = "flex";
      debloatToggle.textContent = "Hide Apps";
    }
  } catch (err) {
    alert("Error checking license: " + err.message);
  }
});

// 🧾 Tombol Activate License
document.getElementById("licenseActivate").addEventListener("click", async () => {
  const code = document.getElementById("licenseInput").value.trim();
  if (!code) return alert("Please enter your license code.");
  try {
    await exec(`echo "${code}" > "${LICENSE_FILE}"`);
    document.getElementById("licenseMsg").innerText = "✅ License saved successfully.";
  } catch (e) {
    document.getElementById("licenseMsg").innerText = "❌ Failed to save license: " + e.message;
  }
});

// 🔧 Fungsi Debloat (hanya aktif kalau valid.txt ada)
async function loadApps(type = "user") {
  uninstallOutput.textContent = "Loading apps...";
  appsList.innerHTML = "";
  const cmd = type === "system" ? `pm list packages -s` : `pm list packages -3`;
  const result = await exec(cmd);
  allApps = result.split("\n").map(l => l.replace("package:", "").trim()).filter(Boolean);
  displayApps(allApps);
  uninstallOutput.textContent = `${allApps.length} apps loaded (${type}).`;
}

function displayApps(list) {
  appsList.innerHTML = list
    .map(pkg => `<div><input type="checkbox" value="${pkg}" id="${pkg}"><label for="${pkg}">${pkg}</label></div>`)
    .join("");
}

searchApp.addEventListener("input", () => {
  const query = searchApp.value.toLowerCase();
  const filtered = allApps.filter(pkg => pkg.toLowerCase().includes(query));
  displayApps(filtered);
});

showUserApps.addEventListener("click", () => loadApps("user"));
showSystemApps.addEventListener("click", () => loadApps("system"));

uninstallBtn.addEventListener("click", async () => {
  const checked = Array.from(appsList.querySelectorAll("input:checked")).map(el => el.value);
  if (checked.length === 0) return (uninstallOutput.textContent = "No apps selected.");

  uninstallOutput.textContent = "Uninstalling...\n";
  for (const pkg of checked) {
    uninstallOutput.textContent += `\nUninstalling ${pkg}...`;
    try {
      const result = await exec(`pm uninstall --user 0 ${pkg}`);
      if (result.includes("Failure")) {
        await exec(`pm disable --user 0 ${pkg}`);
        uninstallOutput.textContent += `\n✅ ${pkg} disabled (system app).`;
      } else {
        uninstallOutput.textContent += `\n✅ ${pkg} uninstalled.`;
      }
    } catch (err) {
      uninstallOutput.textContent += `\n❌ ${pkg}: ${err.message}`;
    }
  }
  uninstallOutput.textContent += "\n\nDone.";
});
// ======== Auto Mode (license protected) ========
const AUTO_FILE = "/data/adb/modules/armpit/webroot/assets/auto.txt";
const autoSwitch = document.getElementById("autoSwitch");
const autoSection = document.getElementById("autoSection");
const autoLicenseSection = document.getElementById("autoLicenseSection");
const autoLicenseInput = document.getElementById("autoLicenseInput");
const autoLicenseActivate = document.getElementById("autoLicenseActivate");
const autoLicenseMsg = document.getElementById("autoLicenseMsg");

async function isValidLicense() {
  try {
    const valid = await exec(`if [ -f "${VALID_FILE}" ]; then echo 1; else echo 0; fi`);
    return valid.trim() === "1";
  } catch {
    return false;
  }
}

async function syncAutoSwitch() {
  try {
    const state = (await readFile(AUTO_FILE)).trim().toLowerCase();
    autoSwitch.checked = state === "on";
  } catch {
    autoSwitch.checked = false;
  }
}

// Event handler untuk toggle Auto Mode
autoSwitch.addEventListener("change", async () => {
  const valid = await isValidLicense();
  if (!valid) {
    // Blokir toggle & tampilkan license section
    autoSwitch.checked = false;
    autoLicenseSection.style.display = "flex";
    autoLicenseMsg.textContent = "⚠️ You need a valid license to use Auto Mode.";
    return;
  }

  // Kalau valid → eksekusi
  try {
    if (autoSwitch.checked) {
      await exec(`echo "on" > "${AUTO_FILE}"`);
      autoLicenseMsg.textContent = "✅ Auto Mode activated.";
    } else {
      await exec(`echo "off" > "${AUTO_FILE}"`);
      autoLicenseMsg.textContent = "❎ Auto Mode disabled.";
    }
  } catch (err) {
    autoLicenseMsg.textContent = `❌ Failed: ${err.message}`;
  }
});

// Tombol Activate License untuk Auto Mode
autoLicenseActivate.addEventListener("click", async () => {
  const code = autoLicenseInput.value.trim();
  if (!code) return alert("Please enter your license code.");

  try {
    await exec(`echo "${code}" > "${LICENSE_FILE}"`);
    autoLicenseMsg.textContent = "✅ License saved successfully.";
    autoLicenseSection.style.display = "none";
  } catch (e) {
    autoLicenseMsg.textContent = "❌ Failed to save license: " + e.message;
  }
});

// Sinkronisasi awal saat page load
document.addEventListener("DOMContentLoaded", async () => {
  const valid = await isValidLicense();
  if (valid) {
    autoLicenseSection.style.display = "none";
    await syncAutoSwitch();
  } else {
    autoSwitch.checked = false;
    autoLicenseSection.style.display = "none"; // hidden by default, show only when toggled
  }
});
// ======== User Status Overlay ========
const VALID_TXT = "/data/adb/modules/armpit/webroot/assets/valid.txt";
const userLabelEl = document.getElementById("userLabel");
const userIconEl = document.getElementById("userIcon");

async function updateUserStatus() {
  try {
    const valid = await exec(`if [ -f "${VALID_TXT}" ]; then echo 1; else echo 0; fi`);
    if (valid.trim() === "1") {
      userLabelEl.textContent = "Premium User";
      userIconEl.src = "https://img.icons8.com/pulsar-gradient/48/crown.png";
    } else {
      userLabelEl.textContent = "Regular User";
      userIconEl.src = "https://img.icons8.com/fluency-systems-regular/48/user.png";
    }
  } catch (err) {
    userLabelEl.textContent = "Unknown";
    console.error("updateUserStatus failed:", err);
  }
}

document.addEventListener("DOMContentLoaded", updateUserStatus);
// ======== Get License Button ========
const VALID_TXT_PATH = "/data/adb/modules/armpit/webroot/assets/valid.txt";
const getLicenseRow = document.getElementById("getLicenseRow");
const getLicenseBtn = document.getElementById("getLicenseBtn");

async function setupGetLicense() {
  try {
    const res = await exec(`if [ -f "${VALID_TXT_PATH}" ]; then echo 1; else echo 0; fi`);
    if (res.trim() !== "1") {
      getLicenseRow.style.display = "flex";
    }
  } catch (err) {
    console.error("check valid.txt failed:", err);
  }

  getLicenseBtn.addEventListener("click", async () => {
    try {
      await exec(`am start -a android.intent.action.VIEW -d "https://t.me/kaminarich"`);
    } catch (e) {
      console.error("open link failed:", e);
    }
  });
}

document.addEventListener("DOMContentLoaded", setupGetLicense);
// ============ Init ============
document.addEventListener("DOMContentLoaded", async () => {
  setupSwitches();
  await loadInfo();
  await loadRaiRinStatus();
  await syncSwitchFromFile();
  await loadGov();
  await loadZram();
  await loadLog();
  setupInfoLinks();
  setInterval(loadInfo, 4000);
  setInterval(loadLog, 4000);
});