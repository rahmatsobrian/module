#!/system/bin/sh

MODULE_DIR="/data/adb/modules/armpit"
PERM_SCRIPT="$MODULE_DIR/permission.sh"
ACTION="$MODULE_DIR/action.sh"
LOG_DIR="$MODULE_DIR/webroot/logs"
LOG_FILE="$LOG_DIR/log.txt"
RAIRIN_LOG="$LOG_DIR/RaiRin.txt"
ARMPIT="$MODULE_DIR/core"
mkdir -p "$LOG_DIR"

while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 10
done
sleep 20

echo "[VSYNC] === Disable VSYNC Service Start ===" > "$LOG_FILE"

props=(
  "debug.cpurend.vsync false"
  "debug.egl.vsync false"
  "debug.hwui.vsync false"
  "debug.hwui.disable_vsync true"
  "debug.hwui.skip_vsync true"
  "debug.sf.disable_vsync true"
  "debug.egl.swapinterval 0"
  "debug.hwui.render_thread false"
  "debug.sf.disable_backpressure 1"
  "debug.sf.enable_gl_backpressure 0"
  "vendor.debug.egl.vsync false"
  "vendor.debug.sf.vsync false"
  "vendor.debug.mali.vsync 0"
  "vendor.debug.mali.skip_vsync 1"
  "debug.pvr.vsync 0"
  "persist.sys.gpu_rendering opengl"
)

for entry in "${props[@]}"; do
  key=$(echo "$entry" | awk '{print $1}')
  val=$(echo "$entry" | awk '{print $2}')
  current=$(getprop "$key")
  if [ -n "$current" ]; then
    setprop "$key" "$val"
    echo "[VSYNC] Applied: $key=$val (old=$current)" >> "$LOG_FILE"
  else
    echo "[VSYNC] Skipped: $key (not found)" >> "$LOG_FILE"
  fi
done

echo "[VSYNC] === Safe Disable VSYNC Completed ===" >> "$LOG_FILE"

chmod 0755 "$PERM_SCRIPT"
chmod 0755 "$ACTION"
"$PERM_SCRIPT"
"$MODULE_DIR/core/default"
sleep 2
"$MODULE_DIR/core/balance_oriented"
sleep 5

# === Cek ===
if pidof RaiRin-game >/dev/null 2>&1; then
    echo "on" > "$RAIRIN_LOG"
    echo "[RaiRin] Detected active process: RaiRin-game (status=on)" >> "$LOG_FILE"
else
    echo "off" > "$RAIRIN_LOG"
    echo "[RaiRin] Process RaiRin-game not found (status=off)" >> "$LOG_FILE"
fi
# === Run Bin ===
sleep 10
nohup "$ARMPIT/armpit-valid" >/dev/null 2>&1 &

# === notifikasi sistem ===

su -lp 2000 -c "cmd notification post -S bigtext -t 'ARMPIT' Armpit 'Enjoy Armpit'"