#!/system/bin/sh
# ===============================================
MODDIR="/data/adb/modules/armpit"
SERVICE="$MODDIR/service.sh"
LOGFILE="$MODDIR/webroot/logs/log.txt"
chmod 755 "$SERVICE"

(

    until [ "$(getprop sys.boot_completed)" = "1" ]; do
        sleep 2
    done
    sleep 5

    echo "[ARMPIT] Boot complete — starting service.sh (KernelSU mode)" >> "$LOGFILE"
    date >> "$LOGFILE"

    if [ -f "$SERVICE" ]; then
        /system/bin/sh "$SERVICE" >> "$LOGFILE" 2>&1 &
    else
        echo "[ARMPIT] ERROR: service.sh not found!" >> "$LOGFILE"
    fi
) &