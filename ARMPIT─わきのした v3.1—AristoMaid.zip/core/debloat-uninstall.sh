#!/system/bin/sh


INPUT=$(cat)
PKGS=$(echo "$INPUT" | tr -d '[]"' | tr ',' ' ')

for pkg in $PKGS; do
  echo "[*] Uninstalling $pkg..."
  su -c "pm uninstall -k --user 0 $pkg" && echo "✓ $pkg uninstalled" || echo "✗ Failed: $pkg"
done