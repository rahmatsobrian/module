#!/system/bin/sh

FILTER="$1"
TMP_FILE="/data/local/tmp/app_list.txt"

if [ "$FILTER" = "system" ]; then
  pm list packages -s | cut -d':' -f2 > "$TMP_FILE"
else
  pm list packages -3 | cut -d':' -f2 > "$TMP_FILE"
fi

cat "$TMP_FILE"
rm -f "$TMP_FILE"