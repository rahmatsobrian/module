#!/system/bin/sh

RAM_TOTAL_KB=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
RAM_FREE_KB=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)
RAM_TOTAL_GB=$(( (RAM_TOTAL_KB + 1048576 - 1) / 1048576 ))
RAM_FREE_GB=$(( (RAM_FREE_KB + 1048576 - 1) / 1048576 ))

get_cpu_codename() {
  local codename=$(getprop ro.mediatek.platform)
  [ -z "$codename" ] && codename=$(getprop ro.board.platform)
  [ -z "$codename" ] && codename=$(grep -m1 'Hardware' /proc/cpuinfo | cut -d ':' -f2 | sed 's/^[ \t]*//')
  echo "${codename:-unknown}"
}
ui_print "=========================================="
ui_print "[ARMPIT─ わきのした]"
ui_print "    ___       ___       ___   "
ui_print "   /\\  \\     /\\  \\     /\\__\\  "
ui_print "  /::\\  \\   /::\\  \\   /::L_L_ "
ui_print " /::\\:\\__\\ /::\\:\\__\\ /:/L:\\__\\"
ui_print " \\/\\::/  / \\;:::/  / \\/_/:/  /"
ui_print "   /:/  /   |:\\/__/    /:/  / "
ui_print "   \\/__/     \\|__|     \\/__/  "
ui_print "    ___       ___       ___   "
ui_print "   /\\  \\     /\\  \\     /\\  \\  "
ui_print "  /::\\  \\   _\\:\\  \\    \\:\\  \\ "
ui_print " /::\\:\\__\\ /\\/::\\__\\   /::\\__\\"
ui_print " \\/\\::/  / \\::/\\/__/  /:/\\/__/"
ui_print "    \\/__/   \\:\\__\\    \\/__/   "
ui_print "             \\/__/            "
# Header
ui_print "=========================================="
ui_print " "
ui_print "DEVICE       : $(getprop ro.build.product)"
ui_print "MODEL        : $(getprop ro.product.model)"
ui_print "MANUFACTURER : $(getprop ro.product.system.manufacturer)"
ui_print "BOARD        : $(getprop ro.product.board)"
ui_print "CODENAME     : $(get_cpu_codename)"
ui_print "ANDROID VER  : $(getprop ro.build.version.release)"
ui_print "RAM       : ${RAM_TOTAL_GB} GB total / ${RAM_FREE_GB} GB free"
ui_print "KERNEL       : $(uname -r)"
ui_print " "

# Dirty splash
sleep 1.2
case "$((RANDOM % 12 + 1))" in
  1)  ui_print "- CPU engaged. GPU locked. Armpit takes full control." ;;
  2)  ui_print "- Bottlenecks eliminated. Armpit runs it raw and fast." ;;
  3)  ui_print "- Fast boots. Smooth frames. Maximum throughput delivered." ;;
  4)  ui_print "- Armpit goes deeper than your average governor ever could." ;;
  5)  ui_print "- This isn’t tweaking. This is full domination of your scheduler." ;;
  6)  ui_print "- I/O tuned. CPU calibrated. Memory disciplined. It's on." ;;
  7)  ui_print "- Memory stays tight. Performance stays consistent. No compromise." ;;
  8)  ui_print "- Frames won’t stutter. Armpit keeps them in line, no exceptions." ;;
  9)  ui_print "- Demands peak response? Armpit delivers, repeatedly." ;;
  10) ui_print "- Overclocking is cute. Armpit pushes limits professionally." ;;
  11) ui_print "- No lag. No mercy. Just full execution from boot to load." ;;
  12) ui_print "- Direct to kernel. Sysfs domination. Armpit doesn’t ask twice." ;;
esac

# Footer
ui_print " "
ui_print "=========================================="
ui_print "ARMPIT enabled. Expect no compromises."
ui_print "=========================================="