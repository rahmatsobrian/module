#!/bin/sh
MODDIR=${0%/*}

$MODDIR/UNLOCKER


settings put system min_refresh_rate 120
settings put system peak_refresh_rate 90