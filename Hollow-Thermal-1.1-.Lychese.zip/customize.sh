#!/system/bin/sh

# Module Configuration
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

# Create Hollow Directory
ui_print "- Startup Installing"
mkdir -p /data/hollow
touch /data/hollow/thermal_mode

# Webroot
ui_print "- Extracting Webroot"
unzip -qo "$ZIPFILE" 'webroot' -d "$MODPATH"

# Extract 
ui_print "- Extracting Hollow Icon"
unzip -qo "$ZIPFILE" 'hollow_icon.png' -d "$MODPATH"
mv "$MODPATH/webroot/hollow_icon.png" "/data/local/tmp/hollow_icon.png"
rm -f "$MODPATH/webroot/hollow_icon.png"

# Set Module Permissions
ui_print "- Setting Permission"
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive "$MODPATH/system/bin" 0 2000 0755 0755

# Extract Additional Files and move them
ui_print "- Extracting Files"
unzip -qo "$ZIPFILE" 'service.sh' -d "$MODPATH"
unzip -qo "$ZIPFILE" 'mode' -d "$MODPATH"
unzip -qo "$ZIPFILE" 'common/*' -d "$MODPATH"
unzip -qo "$ZIPFILE" 'system/*' -d "$MODPATH"

# Notes
ui_print "- Edit Thermal Mode On WebUI"
ui_print "- Credit Source: "
ui_print "- @hirauki "
ui_print "- @MiAzami " 

# Easter Egg Messages
case "$((RANDOM % 3 + 1))" in
    1) ui_print "- Let's Bring the Future" ;;
    2) ui_print "- Hollow in void it's really darked !" ;;
    3) ui_print "- Cold but not Cruel !" ;;
esac

