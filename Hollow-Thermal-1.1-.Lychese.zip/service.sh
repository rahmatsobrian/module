#!/system/bin/sh
MODDIR=${0%/*}

# Wait for boot completion
while [ -z "$(getprop sys.boot_completed)" ]; do
    sleep 1
done

# Paths
Thermal_status="/data/hollow/thermal_mode"
Logging="/storage/emulated/0/hollow.log"
Uneed_file="/data/hollow/uneed"
Default="Normal"

if [ -f "$Thermal_status" ]; then
    thermal_mode_satus=$(cat "$Thermal_status" | tr '[:upper:]' '[:lower:]' | xargs)
    case "$thermal_mode_satus" in
        "normal"|"intense") ;; # Valid modes
        *) thermal_mode_satus="$Default" ;;
    esac
else
    thermal_mode_satus="$Default"
fi

if [ -f "$Uneed_file" ]; then
    uneed_value=$(cat "$Uneed_file" | tr -d '[:space:]')
    for pkg in com.samsung.android.game.gos com.xiaomi.powerchecker com.xiaomi.joyose; do
        if pm list packages | grep -q "$pkg"; then
            case "$uneed_value" in
                "1")
                    pm disable-user --user 0 "$pkg" >/dev/null 2>&1
                    log_activity "Disabled package: $pkg"
                    ;;
                "0")
                    pm enable "$pkg" >/dev/null 2>&1
                    log_activity "Enabled package: $pkg"
                    ;;
            esac
        fi
    done
fi

rm $Logging

#####################
# Logging function ###
####################

log_activity() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$Logging"
}

#####################################
## Common Thermal Functions ##
#####################################

# Enhanced process killer with fallback to pkill -9
kill_thermal_process() {
    local pid=$1
    local name=$2
    if [ -n "$pid" ]; then
        kill -SIGSTOP "$pid" 2>/dev/null
        sleep 0.5
        if ps -p "$pid" > /dev/null; then
            kill -9 "$pid" 2>/dev/null
            log_activity "Force-killed $name (PID $pid) with SIGKILL"
        fi
        # Final fallback: pkill -9 if PID still exists
        if ps -p "$pid" > /dev/null; then
            pkill -9 -f "$name" 2>/dev/null
            log_activity "Nuclear pkill -9 executed on $name"
        fi
    fi
}

disable_thermal_zones() {
    for zone in /sys/class/thermal/thermal_zone*/mode; do
        if [ -f "$zone" ] && [ "$(cat "$zone")" != "disabled" ]; then
            chmod 644 "$zone"
            echo "disabled" > "$zone"
        fi
    done
    
    for zone2 in /sys/class/thermal/thermal_zone*/policy; do
        if [ -f "$zone2" ] && [ "$(cat "$zone2")" != "userspace" ]; then
            echo "userspace" > "$zone2"
        fi
    done
    log_activity "Disabled Thermal Zones"
}

stop_thermal_services() {
    thermal_services() {
        find /system/etc/init /vendor/etc/init /odm/etc/init -type f 2>/dev/null | 
        xargs grep -l '^service.*thermal' 2>/dev/null | 
        xargs grep -h '^service' | awk '{print $2}'
    }
    
    for svc in $(thermal_services); do
        if getprop | grep -q "init.svc.$svc.*running"; then
            stop "$svc"
            sleep 0.5
            pid=$(pidof "$svc")
            [ -n "$pid" ] && kill_thermal_process "$pid" "$svc"
        fi
    done
    
    # Additional thermal services to stop
    for dead in android.hardware.thermal-service.mediatek android.hardware.thermal@2.0-service.mtk; do
        if getprop | grep -q "init.svc.$dead.*running"; then
            stop "$dead"
            pid=$(pidof "$dead")
            [ -n "$pid" ] && kill -SIGSTOP "$pid"
        fi
    done
    
    # Freeze all running thermal processes
    for pid in $(pgrep thermal); do
        kill -SIGSTOP "$pid"
    done
    
    # Fall back if top isnt work
    thermal() {
    find /system/etc/init /vendor/etc/init /odm/etc/init -type f 2>/dev/null | xargs grep -h "^service" | awk '{print $2}' | grep thermal
    }

    thermal_service=$(thermal)

    if [ "$thermal_service" != "vendor.thermal-hal" ] && [ "$thermal_service" != "android.hardware.thermal-service.mediatek" ]; then
      stop "$thermal_service"
      sleep 0.5
       pid=$(pidof "$thermal_service")
         if [ -n "$pid" ]; then
        kill -9 "$pid"
      fi
    fi
}

disable_gpu_limits() {
    if [ -f "/proc/gpufreq/gpufreq_power_limited" ]; then
        for setting in ignore_batt_oc ignore_batt_percent ignore_low_batt ignore_thermal_protect ignore_pbm_limited; do
            if ! grep -q "$setting 1" "/proc/gpufreq/gpufreq_power_limited"; then
                echo "$setting 1" > /proc/gpufreq/gpufreq_power_limited
            fi
        done
    fi
}

set_cpu_limits() {
    if [ -f /sys/devices/virtual/thermal/thermal_message/cpu_limits ]; then
        for cpu in 0 2 4 6 7; do
            maxfreq_path="/sys/devices/system/cpu/cpu$cpu/cpufreq/cpuinfo_max_freq"
            if [ -f "$maxfreq_path" ]; then
                maxfreq=$(cat "$maxfreq_path")
                if [ -n "$maxfreq" ] && [ "$maxfreq" -gt 0 ]; then
                    current_limit=$(grep "cpu$cpu" /sys/devices/virtual/thermal/thermal_message/cpu_limits)
                    if [ -z "$current_limit" ] || [ "$current_limit" != "cpu$cpu $maxfreq" ]; then
                        echo "cpu$cpu $maxfreq" > /sys/devices/virtual/thermal/thermal_message/cpu_limits
                    fi
                fi
            fi
        done
    fi
}

disable_ppm_policies() {
    if [ -d /proc/ppm ] && [ -f /proc/ppm/policy_status ]; then
        for idx in $(grep -E 'FORCE_LIMIT|PWR_THRO|THERMAL' /proc/ppm/policy_status | awk -F'[][]' '{print $2}'); do
            current_status=$(grep "^$idx " /proc/ppm/policy_status | awk '{print $2}')
            if [ "$current_status" != "0" ]; then
                echo "$idx 0" > /proc/ppm/policy_status
            fi
        done
    fi
}

hide_thermal_monitoring() {
    find /sys/devices/virtual/thermal -type f -exec sh -c '
        for file; do
            if [ "$(stat -c "%a" "$file")" != "0" ]; then
                chmod 000 "$file"
            fi
        done
    ' sh {} +
}

disable_thermal_stats() {
    if [ "$(cmd thermalservice get-status)" != "0" ]; then
        cmd thermalservice override-status 0
    fi
}

disable_charging_throttle() {
    if [ -f /proc/mtk_batoc_throttling/battery_oc_protect_stop ]; then
        if [ "$(cat /proc/mtk_batoc_throttling/battery_oc_protect_stop)" != "stop 1" ]; then
            echo "stop 1" > /proc/mtk_batoc_throttling/battery_oc_protect_stop
        fi
    fi
}

reset_thermal_properties() {
    # Clear init.svc_ properties only if they exist
    for prop in $(getprop | awk -F '[][]' '/init\.svc_/ {print $2}'); do
        if [ -n "$prop" ]; then
            resetprop -n "$prop" ""
        fi
    done
    
    getprop | awk -F '[][]' '/ro.*thermal/ {print $2}' | while read -r prop; do
        if [ "$(getprop "$prop")" != "0" ]; then
            resetprop -n "$prop" 0
        fi
    done

    for prop in $(getprop | grep thermal | cut -f1 -d] | cut -f2 -d[ | grep -F init.svc.); do
        if [ "$(getprop "$prop")" != "stopped" ]; then
            setprop "$prop" stopped
        fi
    done
    
    for prop in $(getprop | grep thermal | cut -f1 -d] | cut -f2 -d[ | grep -F init.svc_); do
        setprop "$prop" ""
    done
    
    log_activity "Reset Thermal Properties"
}

#####################################
## Normal Mode (Balanced) ##
#####################################

normal_mode() {
    disable_thermal_zones
    reset_thermal_properties
    disable_gpu_limits
    set_cpu_limits
    hide_thermal_monitoring
    disable_thermal_stats
}

#####################################
## Intense Mode (Aggressive) ##
#####################################

intense_mode() {
    normal_mode
    disable_ppm_policies
    disable_charging_throttle
    stop_thermal_services
    
    # Aggressively kill all thermal-related processes
    for pid in $(pgrep -f thermal); do
        kill_thermal_process "$pid" "thermal"
    done
    
    # Target specific stubborn services
    for dead in android.hardware.thermal-service.mediatek android.hardware.thermal@2.0-service.mtk; do
        pid=$(pidof "$dead")
        [ -n "$pid" ] && kill_thermal_process "$pid" "$dead"
    done
    
    [ -f /sys/class/kgsl/kgsl-3d0/throttling ] && echo "0" > /sys/class/kgsl/kgsl-3d0/throttling
    [ -f /sys/class/kgsl/kgsl-3d0/force_clk_on ] && echo "1" > /sys/class/kgsl/kgsl-3d0/force_clk_on
}

#####################################
## Main Execution ##
#####################################

case "$thermal_mode_satus" in
    "intense")
        intense_mode
        notify_messaging="Running in Intense mode"
        ;;
    *)
        normal_mode
        notify_messaging="Running in Normal mode"
        thermal_mode_satus="Normal"
        ;;
esac

# Notification
su -lp 2000 -c "cmd notification post -i 'file:///data/local/tmp/hollow_icon.png' -t 'Hollow Thermal' -I 'file:///data/local/tmp/hollow_icon.png' 'thermal' '$notify_messaging'" > /dev/null 2>&1

log_activity "Thermal management completed in $thermal_mode_satus mode"