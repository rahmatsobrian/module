#!/system/bin/sh
SCRIPT_DIR="/data/adb/modules/thunderclash"
MODE="$SCRIPT_DIR/mode"
LOG_FILE="/data/local/tmp/heap.log"
TMP="/data/local/tmp/thunderclash"
    [ -f "$LOG_FILE" ] && rm -f "$LOG_FILE"
# Set permission executable
[ -d "$MODE" ] && chmod 0755 "$MODE"/* 2>/dev/null
chmod 0755 "$SCRIPT_DIR/elmalware"
safe_echo() {
    local value="$1"
    local file="$2"
    [ -w "$file" ] && echo "$value" > "$file"
}
distrace() {
    safe_echo "0" /sys/kernel/tracing/options/overwrite
    safe_echo "0" /sys/kernel/tracing/options/record-tgid

    # Clear trace buffer
    for trace_file in \
        /sys/kernel/tracing/instances/mmstat/trace \
        /sys/kernel/tracing/trace \
        $(find /sys/kernel/tracing/per_cpu/ -type f -name trace 2>/dev/null); do
        [ -w "$trace_file" ] && safe_echo "" "$trace_file"
    done

    # Matikan tracing
    safe_echo "0" /sys/kernel/tracing/tracing_on
    safe_echo "0" /sys/kernel/tracing/buffer_size_kb

    # Service trace cleanup
    cmd accessibility stop-trace 2>/dev/null
    cmd migard dump-trace false 2>/dev/null
    cmd migard start-trace false 2>/dev/null
    cmd migard stop-trace true 2>/dev/null
    cmd migard trace-buffer-size 0 2>/dev/null
    cmd input_method tracing stop 2>/dev/null
    cmd window tracing size 0 2>/dev/null
    cmd window tracing stop 2>/dev/null
}
enable_fast_dvfs() {
    for path in \
        /sys/kernel/ged/hal/fast_dvfs \
        /sys/kernel/ged/hal/fdvfs \
        /sys/kernel/ged/hal/enable_fdvfs \
        /sys/kernel/ged/hal/boost_gpu_enable; do
        [ -e "$path" ] && echo 1 > "$path"
    done
}
disable_texture_filtering() {
    local tuner="/sys/kernel/ged/gpu_tuner/custom_hint_set"
    [ -w "$tuner" ] || return
    echo anisotropic_disable > "$tuner"
    echo trilinear_disable > "$tuner"
    resetprop debug.cpurend.vsync false
    resetprop debug.hwui.disable_vsync true
}
additional() {
    TOTAL_RAM_KB=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
    TOTAL_RAM_MB=$((TOTAL_RAM_KB / 1024))
    echo "Original RAM: ${TOTAL_RAM_MB} MB" >> "$LOG_FILE"
    if [ "$TOTAL_RAM_MB" -ge 12000 ]; then
        RAM_ROUNDED=12        
    elif [ "$TOTAL_RAM_MB" -ge 8000 ]; then
        RAM_ROUNDED=12           
    elif [ "$TOTAL_RAM_MB" -ge 7500 ]; then
        RAM_ROUNDED=8
    elif [ "$TOTAL_RAM_MB" -ge 5000 ]; then
        RAM_ROUNDED=6        
    else
        RAM_ROUNDED=$((TOTAL_RAM_MB / 1000))
    fi
    echo "Rounded RAM: ${RAM_ROUNDED} GB" >> "$LOG_FILE"
    case $RAM_ROUNDED in
        12)
            resetprop dalvik.vm.heapgrowthlimit 1024m
            resetprop dalvik.vm.heapsize 1536m
            resetprop dalvik.vm.heapminfree 16m
            resetprop dalvik.vm.heapmaxfree 32m
            echo "Applied RAM 12GB Config" >> "$LOG_FILE"
            ;;
        8)
            resetprop dalvik.vm.heapgrowthlimit 768m
            resetprop dalvik.vm.heapsize 1024m
            resetprop dalvik.vm.heapminfree 12m
            resetprop dalvik.vm.heapmaxfree 24m
            echo "Applied RAM 8GB Config" >> "$LOG_FILE"
            ;;
        6)
            resetprop dalvik.vm.heapgrowthlimit 512m
            resetprop dalvik.vm.heapsize 768m
            resetprop dalvik.vm.heapminfree 8m
            resetprop dalvik.vm.heapmaxfree 16m
            echo "Applied RAM 6GB Config" >> "$LOG_FILE"
            ;;
        *)
            echo "Heap tweak skipped, RAM <6GB" >> "$LOG_FILE"
            ;;
    esac
    # Rendering & GPU tweaks
    resetprop debug.sf.disable_client_composition_cache 1
    resetprop debug.hwui.skia_atrace_enabled false
    resetprop ro.config.enable.hw_accel true
    resetprop debug.hwui.render_dirty_regions false
    # ART / Dalvik universal settings
    resetprop dalvik.vm.systemuicompilerfilter speed
    resetprop dalvik.vm.systemservercompilerfilter speed
    resetprop ro.config.low_ram false
    
    # less anim
    settings put global window_animation_scale 0.8
    settings put global transition_animation_scale 0.8
    settings put global animator_duration_scale 0.8
}
# Eksekusi utama
disable_texture_filtering
enable_fast_dvfs
# Tunggu boot selesai
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 10
done
"$SCRIPT_DIR/cp.sh"
"$SCRIPT_DIR/elmalware"
[ -f "$SCRIPT_DIR/soc.sh" ] && sh "$SCRIPT_DIR/soc.sh"
[ -x "$MODE/crt" ] && "$MODE/crt"

additional
sleep 10
##############################
#========== El Malware ===========#
##############################

[ -x "$MODE/save" ] && "$MODE/save"
[ -x "$TMP/distrace" ] && "$TMP/distrace"
[ -x "$MODE/normal" ] && "$MODE/normal"
[ -x "$SCRIPT_DIR/thunder" ] && nohup "$SCRIPT_DIR/thunder" >/dev/null 2>&1 &