#!/system/bin/sh

level=2
echo "Compression level: $level"

# System Messages
kernel_unsupported="Kernel 不対応 — Thunder cannot awaken on this kernel."
swap_too_low="SWAP 空き容量が足りません — Lightning skipped due to low space."
reclaim_completed="Memory 解放 completed — energy fully reclaimed."
calculation_error="計算エラー — could not summon memory capacity."
memory_enough="Memory—Optimal and fully charged"
write_back_completed="ZRAM write-back 完了 — sufficient memory released by Thunder"
# Drop caches if not level 0 (real-time acceleration)
if [[ "$level" != "0" ]]; then
  echo 3 > /proc/sys/vm/drop_caches
fi

modify_path='none'
friendly=false
use_memcg=false

# Detect memory control path
if [[ -e /sys/fs/cgroup/memory/memory.swappiness ]]; then
  scene_memcg="/sys/fs/cgroup/memory"
elif [[ -d /dev/memcg ]]; then
  scene_memcg="/dev/memcg"
fi

# Determine which memory setting to modify
if [[ -f '/proc/sys/vm/extra_free_kbytes' ]]; then
  modify_path='/proc/sys/vm/extra_free_kbytes'
  friendly=true
elif [[ -d $scene_memcg ]]; then
  use_memcg=true
elif [[ -f '/proc/sys/vm/min_free_kbytes' ]]; then
  modify_path='/proc/sys/vm/min_free_kbytes'
else
  am start -a android.intent.action.MAIN -e toasttext "$kernel_unsupported" -n bellavita.toast/.MainActivity
  return 1
fi

min_free_kbytes=$(cat $modify_path)

# Read memory info
MemTotal=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
MemFree=$(awk '/MemFree/ {print $2}' /proc/meminfo)
SwapFree=$(awk '/SwapFree/ {print $2}' /proc/meminfo)

# Calculate target reclaim size based on level
case "$level" in
  3)
    TargetRecycle=$((MemTotal * (friendly ? 55 : 26) / 100))
    ;;
  2)
    TargetRecycle=$((MemTotal * (friendly ? 35 : 18) / 100))
    ;;
  0)
    TargetRecycle=$((MemTotal * (friendly ? 14 : 10) / 100))
    ;;
  *)
    TargetRecycle=$((MemTotal * (friendly ? 20 : 12) / 100))
    ;;
esac

zram_writeback() {
  [[ ! -f /sys/block/zram0/backing_dev ]] || ! grep -q zram0 /proc/swaps && return 0

  echo 0 > /sys/block/zram0/writeback_limit_enable
  local backing_dev
  backing_dev=$(cat /sys/block/zram0/backing_dev)

  if [[ -n "$backing_dev" && "$backing_dev" != "none" ]]; then
    for idle_time in 1800 600 300 all; do
      echo "$idle_time" > /sys/block/zram0/idle
      for wb_type in incompressible huge_idle idle; do
        echo "$wb_type" > /sys/block/zram0/writeback
        MemFree=$(awk '/MemFree/ {print $2}' /proc/meminfo)
        [[ $MemFree -gt $TargetRecycle ]] && return 1
      done
    done
  fi
  return 0
}

apps_memcg() {
  [[ $(getprop ro.build.version.sdk) -lt 28 || ! -d $scene_memcg ]] && return

  mkdir -p "$scene_memcg/apps" "$scene_memcg/system"
  for set in "" "/apps" "/system"; do
    echo 1 > "$scene_memcg$set/memory.use_hierarchy"
    echo 1 > "$scene_memcg$set/memory.oom_control"
    echo 1 > "$scene_memcg$set/memory.move_charge_at_immigrate"
  done

  dumpsys activity lru | grep '#' | while read -r line; do
    for col in $line; do
      if [[ "$col" == */* ]]; then
        pid=${col%%:*}
        uid=${col##*/}
        [[ "$uid" == *i* ]] && uid=${uid%%i*}
        cgroup=$(grep memory "/proc/$pid/cgroup" | awk -F '/' '{print $2}')
        [[ -z "$cgroup" ]] && echo "$pid" > "$scene_memcg/${uid:0:1 == u ? "apps" : "system"}/cgroup.procs"
      fi
    done
  done
}

memcg_reclaim() {
  local cmd=""

  # Handle scene_idle group
  if [[ -e "$scene_memcg/scene_idle" ]]; then
    local limit=$(cat "$scene_memcg/scene_idle/memory.soft_limit_in_bytes")
    [[ "$limit" == "9223372036854771712" ]] && limit='384M'
    cmd+="echo $limit > $scene_memcg/scene_idle/memory.limit_in_bytes\n"
  fi

  # Apps group
  if [[ -e "$scene_memcg/apps" ]]; then
    local usage=$(cat "$scene_memcg/apps/memory.usage_in_bytes")
    local limit_kb=$((usage / 1000 - TargetRecycle))
    [[ $limit_kb -lt 393216 ]] && limit_kb=393216
    cmd+="echo ${limit_kb}K > $scene_memcg/apps/memory.limit_in_bytes\n"
  fi

  # System + scene_active
  for set in scene_active system; do
    if [[ -e "$scene_memcg/$set" ]]; then
      local usage=$(cat "$scene_memcg/$set/memory.usage_in_bytes")
      local in_swap=$(awk '/^swap/ {print $2}' "$scene_memcg/$set/memory.stat")
      local limit_kb=$((usage * 50 / 100 / 1000))
      [[ $limit_kb -lt 393216 ]] && limit_kb=393216
      cmd+="echo ${limit_kb}K > $scene_memcg/$set/memory.limit_in_bytes\n"
    fi
  done

  echo -e "$cmd" > /cache/force_empty.sh
  nohup sh /cache/force_empty.sh >/dev/null &
}

memcg_reclaim_stop() {
  killall 'sh /cache/force_empty.sh'
  rm -f /cache/force_empty.sh
  for set in apps system scene_active scene_idle; do
    [[ -e "$scene_memcg/$set" ]] && echo '9223372036854771712' > "$scene_memcg/$set/memory.limit_in_bytes"
  done
}

force_reclaim() {
  local reclaim_size=$((TargetRecycle - MemFree))
  local swap_required=$((reclaim_size * 130 / 100))

  if [[ $SwapFree -lt $swap_required ]]; then
    [[ "$level" == "0" ]] && {
      am start -a android.intent.action.MAIN -e toasttext "$swap_too_low" -n bellavita.toast/.MainActivity
      return 5
    }
    reclaim_size=$((SwapFree / 2))
  fi

  TargetRecycle=$((reclaim_size + MemFree))

  if [[ $reclaim_size -gt 0 ]]; then
    $use_memcg && {
      apps_memcg
      memcg_reclaim
    } || echo $TargetRecycle > $modify_path

    local duration_limit=30
    local reclaim_timeout=$((reclaim_size / 1024 / (level == 0 ? 120 : 60) + 2))
    [[ $reclaim_timeout -gt $duration_limit ]] && reclaim_timeout=$duration_limit

    while [[ $reclaim_timeout -gt 0 ]]; do
      sleep 0.1
      MemFree=$(awk '/MemFree/ {print $2}' /proc/meminfo)
      [[ $((TargetRecycle - MemFree)) -lt 100 ]] && break
      $use_memcg && [[ -z "$(pidof -x force_empty.sh)" ]] && break
      SwapFree=$(awk '/SwapFree/ {print $2}' /proc/meminfo)
      [[ $SwapFree -lt 100 ]] && break
      reclaim_timeout=$((reclaim_timeout - 1))
    done

    $use_memcg && memcg_reclaim_stop || echo $min_free_kbytes > $modify_path
    am start -a android.intent.action.MAIN -e toasttext "$reclaim_completed" -n bellavita.toast/.MainActivity
  else
    am start -a android.intent.action.MAIN -e toasttext "$calculation_error" -n bellavita.toast/.MainActivity
  fi
}

# Main logic
if [[ $MemFree -gt $TargetRecycle ]]; then
  am start -a android.intent.action.MAIN -e toasttext "$memory_enough" -n bellavita.toast/.MainActivity
else
  zram_writeback
  [[ $? -eq 1 ]] && am start -a android.intent.action.MAIN -e toasttext "$write_back_completed" -n bellavita.toast/.MainActivity || force_reclaim
fi

[[ -f /proc/sys/vm/compact_memory ]] && echo 1 > /proc/sys/vm/compact_memory