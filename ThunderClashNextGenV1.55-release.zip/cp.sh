#!/system/bin/sh
SRC="/data/adb/modules/thunderclash/mode"
DST="/data/local/tmp/thunderclash"

mkdir -p "$DST"


files=("color" "zram" "skiagl" "vulkan" "perf2" "bypass" "unbypass" "dislog" "reslog" "distrace" "reset")

for f in "${files[@]}"; do
    FILEPATH="$SRC/$f"

    if [ -e "$FILEPATH" ] && [ ! -d "$FILEPATH" ]; then
        mv "$FILEPATH" "$DST/"
        echo "Moved $f to $DST"
    else
        echo "Skipping $f (not found or is a directory)"
    fi
done

exit 0