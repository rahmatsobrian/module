#!/system/bin/sh
action="Summoning Thunder..."
action1="Lightning Strike!"
action2="Memory Cleansing Complete"
MODPATH="/data/adb/modules/thunderclash"
ZRAM=$(cat /sys/block/zram0/disksize)
SWAP=$(cat /proc/sys/vm/swappiness)

am start -a android.intent.action.MAIN -e toasttext "$action" -n bellavita.toast/.MainActivity
sleep 2

# Set temporary swappiness
echo 10 > /proc/sys/vm/swappiness

# Load exclusions
EXCLUDES=$(cat "$MODPATH/whitelist.txt" 2>/dev/null)
EXCLUDES2=$(cat "$MODPATH/gamelist.txt" 2>/dev/null)
ALL_EXCLUDES="$EXCLUDES $EXCLUDES2"

echo ""
echo "[Thunder] Targeting user apps (Whitelist & Gamelist Protected)..."
ALL_APPS=$(pm list packages -3 | cut -f2 -d:)

am start -a android.intent.action.MAIN -e toasttext "$action1" -n bellavita.toast/.MainActivity

for APP in $ALL_APPS; do
    SKIP=0
    for EXC in $ALL_EXCLUDES; do
        if [ "$APP" = "$EXC" ]; then
            echo "  Protected: $APP"
            SKIP=1
            break
        fi
    done
    [ $SKIP -eq 1 ] && continue
    echo "  Striking: $APP"
    am force-stop "$APP"
done

# Clean RAM
echo ""
echo "[Thunder] Purging memory..."
echo 1 > /proc/sys/vm/compact_memory
echo 3 > /proc/sys/vm/drop_caches
sleep 2

# Reset ZRAM
echo "[Thunder] Resetting ZRAM..."
swapoff /dev/block/zram0
echo 1 > /sys/block/zram0/reset
echo "$ZRAM" > /sys/block/zram0/disksize
mkswap /dev/block/zram0
swapon /dev/block/zram0

# Restore swappiness
echo "$SWAP" > /proc/sys/vm/swappiness
sleep 1

# Final memory compact
echo "[Thunder] Merging memory to the world..."
"$MODPATH/compress.sh"

echo ""
echo "RAM & cache have been cleansed by Thunder."
echo "================================"
sleep 1
#am start -a android.intent.action.MAIN -e toasttext "$action2" -n bellavita.toast/.MainActivity