#!/system/bin/sh
CPU_GOV="/sys/devices/system/cpu/cpu0/cpufreq"
DEST_DIR="/data/local/tmp/thunder_default"
DEST_FILE="$DEST_DIR/governor_default.txt"
DND="$DEST_DIR/dnd.txt"
PRIORITY="$DEST_DIR/priority.txt"
mkdir -p "$DEST_DIR"
# Simpan governor default
if [ -f "$CPU_GOV/scaling_governor" ]; then
    gov=$(tr '[:upper:]' '[:lower:]' < "$CPU_GOV/scaling_governor")
else
    gov="schedutil"
fi
echo "$gov" > "$DEST_FILE"

# --- FUNGSI FALLBACK DETEKSI SOC ---
get_cpu_name() {
    local codename=$(getprop ro.soc.model)
    [ -z "$codename" ] && codename=$(getprop ro.soc.manufacturer)
    [ -z "$codename" ] && codename=$(getprop ro.mediatek.platform)
    [ -z "$codename" ] && codename=$(getprop ro.board.platform)
    [ -z "$codename" ] && codename=$(grep -m1 'Hardware' /proc/cpuinfo | cut -d ':' -f2 | sed 's/^[ \t]*//')
    echo "${codename:-unknown}" | tr '[:upper:]' '[:lower:]'
}
chipset=$(get_cpu_name)
# Default 0
soc_id=0
# Fokus hanya 1–5
case "$chipset" in
    *mediatek* | *mt[0-9]* )
        soc_id=1 ;;  # MediaTek
    *qualcomm* | *qcom* | *sm[0-9]* | *sdm* | *msm* | *snapdragon* )
        soc_id=2 ;;  # Qualcomm Snapdragon
    *samsung* | *exynos* | *erd* | *s5e* | *universal* )
        soc_id=3 ;;  # Samsung Exynos
    *unisoc* | *ums* | *sp[0-9]* )
        soc_id=4 ;;  # Unisoc / Spreadtrum
    *google* | *tensor* | *gs[0-9]* )
        soc_id=5 ;;  # Google Tensor
esac
echo "$soc_id" > "$DEST_DIR/soc"
# Set default state
cmd notification set_dnd off
echo 0 > "$DND"
echo 1 > "$PRIORITY"