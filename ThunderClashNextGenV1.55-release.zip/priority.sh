#!/system/bin/sh
methods=(
    "dumpsys activity activities 2>/dev/null | grep -m 1 'mResumedActivity' | sed -E 's/.* ([^ ]+)\/.*/\1/'"
    "dumpsys window windows 2>/dev/null | grep -m 1 'mCurrentFocus' | sed -E 's/.* ([^ ]+)\/.*/\1/'"
    "dumpsys activity top 2>/dev/null | grep -m 1 'ACTIVITY' | awk '{print \$2}' | cut -d/ -f1"
    "dumpsys activity recents 2>/dev/null | grep -m 1 'Recent #0' | sed -E 's/.*A=([^ ]+).*/\1/'"
)

PKG=""
for cmd in "${methods[@]}"; do
    PKG=$(eval "$cmd")
    [ -n "$PKG" ] && break
done

# Validasi
if [ -z "$PKG" ]; then
    echo "error: cannot detect foreground app"
    exit 1
fi

# Ambil PID
PID=$(pidof "$PKG" 2>/dev/null | awk '{print $1}')
if [ -z "$PID" ]; then
    echo "error: no pid found for $PKG"
    exit 1
fi

echo "Setting HIGH priority for $PKG (pid $PID)"

# Set prioritas CPU & IO
renice -n -20 -p "$PID" >/dev/null 2>&1
ionice -c1 -n0 -p "$PID" >/dev/null 2>&1

# Semua thread ke full CPU mask
for TID in $(ls /proc/$PID/task 2>/dev/null); do
    taskset -p ff "$TID" >/dev/null 2>&1
done

exit 0