#!/system/bin/sh
TMPVERIFY="$TMPDIR/.verify"
mkdir -p "$TMPVERIFY"

abort_verify() {
  ui_print "*********************************************************"
  ui_print "! $1"
  ui_print "! Installation aborted. The module may be corrupted."
  ui_print "! Please re-download and try again."
  abort "*********************************************************"
}

verify_file_from_sha256_file() {
  local file="$1"
  local sha_file="${file}.SHA256"

  # Ekstrak file dan SHA256-nya dari ZIP ke folder verify
  unzip -o "$ZIPFILE" "$file" "$sha_file" -d "$TMPVERIFY" >&2 \
    || abort_verify "Failed to extract $file or $sha_file"

  local file_path="$TMPVERIFY/$file"
  local hash_path="$TMPVERIFY/$sha_file"

  # Cek file hasil ekstraksi
  [ -f "$file_path" ] || abort_verify "$file not found after extraction"
  [ -f "$hash_path" ] || abort_verify "$sha_file not found after extraction"

  # Ambil hash yang diharapkan
  local expected_hash
  expected_hash=$(head -n 1 "$hash_path" | tr -d '\r\n')

  # Hitung hash file sebenarnya
  local actual_hash
  actual_hash=$(sha256sum "$file_path" | awk '{print $1}')

  # Bandingkan
  if [ "$actual_hash" != "$expected_hash" ]; then
    abort_verify "Checksum mismatch for $file! Modified/Corrupt detected!"
    
  fi

  ui_print "- Verified integrity of $file"
}
verify_file_from_sha256_file "module.prop"
verify_file_from_sha256_file "service.sh"
#verify_file_from_sha256_file "post-fs-data.sh"
verify_file_from_sha256_file "compress.sh"
verify_file_from_sha256_file "action.sh"
verify_file_from_sha256_file "thunder"
verify_file_from_sha256_file "mode/perf"
verify_file_from_sha256_file "mode/normal"
verify_file_from_sha256_file "mode/powersave"
verify_file_from_sha256_file "mode/reset"
verify_file_from_sha256_file "mode/color"
verify_file_from_sha256_file "mode/skiagl"
verify_file_from_sha256_file "mode/vulkan"


