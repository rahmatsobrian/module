#!/bin/sh
pm uninstall bellavita.toast