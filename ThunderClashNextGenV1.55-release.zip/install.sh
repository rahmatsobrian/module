#!/system/bin/sh

SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE="
"
TMPVERIFY="$TMPDIR/.verify"
mkdir -p "$TMPVERIFY"

print_modname() {
ui_print "                                  +          "; sleep 0.05
ui_print "                         +++++++++++         "; sleep 0.05
ui_print "                        ++     ++ +++        "; sleep 0.05
ui_print "                        ++++++++++++++       "; sleep 0.05
ui_print "                       ++++++++++++ ++       "; sleep 0.05
ui_print "                     +++++++++++++++ ++      "; sleep 0.05
ui_print "                  + ++ ++++++++++++++ ++     "; sleep 0.05
ui_print "                +++++++++++++++++++++++++    "; sleep 0.05
ui_print "               ++++++ ++++++++++++++++ ++    "; sleep 0.05
ui_print "             +++++++ +++++++++++++++++++     "; sleep 0.05
ui_print "           ++ +++++  ++++   ++++++++++       "; sleep 0.05
ui_print "          +++++++++         +++++++++        "; sleep 0.05
ui_print "        ++++++++++         ++++++++          "; sleep 0.05
ui_print "       ++++++++++   +++++ +++++ ++           "; sleep 0.05
ui_print "     +++++++++++++++++++ +++++++             "; sleep 0.05
ui_print "    ++  ++++++++++++++++ +++++               "; sleep 0.05
ui_print "    +++ +++++++++++++++ +++ +                "; sleep 0.05
ui_print "     ++++++++++++++++++++ +                  "; sleep 0.05
ui_print "      ++ +++++++++++++ +                     "; sleep 0.05
ui_print "       +++++++++++++++                       "; sleep 0.05
ui_print "        ++++++++++++++                       "; sleep 0.05
ui_print "        +++ ++    +++                        "; sleep 0.05
ui_print "         +++++++++++                         "; sleep 0.05
ui_print "          +                                  "; sleep 0.05
ui_print ""
ui_print "==============================================="
ui_print "=           Thunder Clash NextGEN             ="
ui_print "=               by kaminarich                 ="
ui_print "==============================================="; sleep 1
}

on_install() {
  ui_print "- Extracting verify.sh"
  unzip -o "$ZIPFILE" 'verify.sh' -d "$TMPDIR" >&2 
  [ ! -f "$TMPDIR/verify.sh" ] && abort_corrupted
  source "$TMPDIR/verify.sh"
  ui_print "> Merging into reality ..."
  sleep 2
  unzip -o "$ZIPFILE" 'mode/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'bypass/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'action.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'cp.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'elmalware' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'priority.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'service.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'Toast.apk' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'compress.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'whitelist.txt' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'gamelist.txt' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'thunder' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'soc.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'dnd' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'webroot/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'uninstall.sh' -d $MODPATH >&2

  if [ -d "/data/adb/modules/thunderclash" ]; then
    rm -rf /data/adb/modules/thunderclash
  fi

  ui_print "> 📢 Installing Toast Application"
  
  #pm uninstall bellavita.toast
  pm install $MODPATH/Toast.apk
  ui_print " "
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0777 0777
}