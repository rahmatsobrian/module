#!/system/bin/sh
# ===============================================
# POW Module Installer Script
# ===============================================
# Dibuat oleh : kaminarich | @kaminarich_here
# ===============================================

# --- Variabel Magisk ---
# Script ini tidak menyertakan system.prop
PROPFILE=true
# Script ini menjalankan skrip post-fs-data
POSTFSDATA=true
# Script ini menjalankan skrip service.sh
LATESTARTSERVICE=true
# Script ini tidak memodifikasi /system, jadi SKIPMOUNT bisa false
SKIPMOUNT=false
# Tidak ada yang perlu diganti di /system
REPLACE=""

# $MODPATH sudah diatur oleh Magisk, tidak perlu mendefinisikannya lagi.
# Baris MODPATH="${MODPATH:-/data/adb/modules/asu}" telah dihapus.

# --- Fungsi Bantuan ---

info_print() {
  # Cek jika file banner ada
  if [ -f "$MODPATH/banner" ]; then
    # awk adalah cara yang lebih efisien daripada cat
    awk '{print}' "$MODPATH/banner"
  fi
  ui_print ""
  sleep 2
  ui_print "Dibuat oleh : kaminarich | @kaminarich_here"
  # Mengurangi waktu sleep agar instalasi lebih cepat
  sleep 3
  ui_print ""
}

# --- Fungsi Instalasi Utama ---

on_install() {
  ui_print " "
  
  # Ekstrak file banner terlebih dahulu
  unzip -o "$ZIPFILE" 'banner' -d "$MODPATH" >&2
  
  # Tampilkan info setelah banner diekstrak
  info_print

  ui_print "> Merging into reality ..."
  sleep 2

  # Ekstrak file-file skrip
  unzip -o "$ZIPFILE" 'post-fs-data.sh' -d "$MODPATH" >&2
  unzip -o "$ZIPFILE" 'service.sh' -d "$MODPATH" >&2
#  unzip -o "$ZIPFILE" 'system.prop' -d "$MODPATH" >&2
  unzip -o "$ZIPFILE" 'module.prop' -d "$MODPATH" >&2
  unzip -o "$ZIPFILE" 'uninstall.sh' -d "$MODPATH" >&2
  # Ekstrak file biner (bin)
  # Pastikan direktori 'bin' ada di dalam zip Anda
  ui_print "> Mengekstrak binari..."
  unzip -o "$ZIPFILE" 'bin/*' -d "$MODPATH" >&2

  ui_print " "
}

# --- Fungsi Pengaturan Izin ---

set_permissions() {
  # Mengatur izin default:
  # Direktori: 0755 (rwxr-xr-x)
  # File: 0644 (rw-r--r--)
  set_perm_recursive "$MODPATH" 0 0 0755 0644

  # Mengatur izin eksekusi (+x) untuk file-file yang diperlukan
  
  # Untuk semua file di dalam /bin
  set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
  
  # Untuk skrip post-fs-data
  set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
  
  # Untuk skrip service
  set_perm "$MODPATH/service.sh" 0 0 0755
}
