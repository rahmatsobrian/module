#!/system/bin/sh
MOD="/data/adb/modules/asu"
BIN="$MOD/bin/ASU"

apply_prop() {
    local prop=$1
    local value=$2
    setprop "$prop" "$value"
    echo "Applied $prop -> $value"
}

# Tunggu system selesai boot
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 10
done
sleep 10

# ART / JIT / Dex2Oat
apply_prop persist.device_config.runtime.dex2oat64.enabled true
apply_prop persist.device_config.runtime.use_art_service true
apply_prop persist.device_config.runtime.use_app_image_startup_cache true
apply_prop persist.device_config.runtime.dedup_boot_image true

# Compiler optimization (SystemUI & SystemServer)
apply_prop dalvik.vm.systemuicompilerfilter speed-profile
apply_prop dalvik.vm.systemservercompilerfilter speed-profile

# Dex2oat threads
apply_prop dalvik.vm.dex2oat-threads 6
apply_prop dalvik.vm.image-dex2oat-threads 6
apply_prop dalvik.vm.boot-dex2oat-threads 6
apply_prop dalvik.vm.dexopt.secondary true
apply_prop dalvik.vm.appimageformat lz4
apply_prop dalvik.vm.minidebuginfo true
apply_prop dalvik.vm.dex2oat-resolve-startup-strings true
apply_prop dalvik.vm.dex2oat-minidebuginfo true


# Jalankan binary setelah boot
chmod 0755 "$BIN"
"$BIN" >/dev/null 2>&1
echo "all done" > /data/local/tmp/asu.log