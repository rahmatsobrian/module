#!/system/bin/sh
MOD="/data/adb/modules/asu"
chmod 0755 "$MOD/service.sh"
if ! command -v resetprop >/dev/null 2>&1; then
    exit 0
fi

# --- Rendering Engine ---
resetprop ro.config.enable.hw_accel true  # universal & aman
resetprop debug.hwui.renderer skiagl      # skiagl lebih stabil dan universal
resetprop debug.renderengine.backend skiaglthreaded 

# --- Compiler Optimization (SystemUI & SystemServer) ---
resetprop dalvik.vm.systemuicompilerfilter speed-profile
resetprop dalvik.vm.systemservercompilerfilter speed-profile

# --- SurfaceFlinger Tweaks ---
resetprop debug.sf.hw 1
resetprop debug.hwui.disable_vsync true
resetprop debug.sf.disable_client_composition_cache 1
resetprop debug.hwui.disable_blur true
resetprop -p persist.sys.scrollingcache disabled
