#!/system/bin/sh

# wait when its done
while [ "$(getprop sys.boot_completed | tr -d '\r')" != "1" ]; do sleep 35; done


nohup stellar_obility > /dev/null 2>&1 &

stellar_profiles

# daemon
stellars




