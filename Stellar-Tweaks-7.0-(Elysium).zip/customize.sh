#!/system/bin/sh

# Module Configuration
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

# Create Stellar Directory
ui_print "- Startup Installing"
mkdir -p /data/stellar
touch /data/stellar/lock
touch /data/stellar/soc

# Game list
ui_print "- Setting Gamelist"
unzip -qo "$ZIPFILE" 'game.txt' -d "$MODPATH"
mv "$MODPATH/game.txt" "/data/stellar/game.txt"
rm -f "$MODPATH/game.txt"

# Webroot
ui_print "- Extracting Webroot"
unzip -qo "$ZIPFILE" 'webroot' -d "$MODPATH"

# Extract 
ui_print "- Extracting Stellar Icon"
unzip -qo "$ZIPFILE" 'stellar_icon.png' -d "$MODPATH"
mv "$MODPATH/webroot/stellar_icon.png" "/data/local/tmp/stellar_icon.png"
rm -f "$MODPATH/webroot/stellar_icon.png"

# Set Module Permissions
ui_print "- Setting Module Permission"
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive "$MODPATH/system/bin" 0 2000 0755 0755
chmod +x "$MODPATH/system/bin/stellars"
chmod +x "$MODPATH/system/bin/stellar_profiles"
chmod +x "$MODPATH/system/bin/stellars_obility"

# Extract Additional Files and move them
ui_print "- Extracting Additional Files"
unzip -qo "$ZIPFILE" 'service/*' -d "$MODPATH"
unzip -qo "$ZIPFILE" 'common/*' -d "$MODPATH"
unzip -qo "$ZIPFILE" 'system/*' -d "$MODPATH"
unzip -qo "$ZIPFILE" 'service.sh' -d "$MODPATH"
unzip -qo "$ZIPFILE" 'post-fs-data.sh' -d "$MODPATH"
unzip -qo "$ZIPFILE" 'system.prop' -d "$MODPATH"

# Easter Egg Messages
case "$((RANDOM % 15 + 1))" in
    1)  ui_print "- Stellar light guides you." ;;
    2)  ui_print "- Whisper to the stars." ;;
    3)  ui_print "- Stellar winds whisper back." ;;
    4)  ui_print "- A constellation remembers." ;;
    5)  ui_print "- Hero? No—just Stellar." ;;
    6)  ui_print "- Stars align for you." ;;
    7)  ui_print "- Stellar calls from the void." ;;
    8)  ui_print "- Darkness fears Stellar." ;;
    9)  ui_print "- Ancient stardust awaits." ;;
    10) ui_print "- Stellar tides rise." ;;
    11) ui_print "- The cosmos watches." ;;
    12) ui_print "- Stellar legends awaken." ;;
    13) ui_print "- Follow Stellar’s trail." ;;
    14) ui_print "- Stellar drops the sky." ;;
    15) ui_print "- A wish upon Stellar." ;;
esac
