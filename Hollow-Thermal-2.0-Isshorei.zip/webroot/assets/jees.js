let commandCounter = 0;

/**
 * Executes a shell command using the KernelSU API.
 * @param {string} command The command to execute.
 * @param {object} options Command options (not used in this script).
 * @returns {Promise<{errno: number, stdout: string, stderr: string}>} A promise that resolves with the command result.
 */
function executeCommand(command, options = {}) {
    return new Promise((resolve, reject) => {
        const callbackName = `exec_callback_${Date.now()}_${commandCounter++}`;

        // Cleanup function to remove the global callback
        const cleanup = () => {
            delete window[callbackName];
        };

        // Define the global callback function
        window[callbackName] = (errno, stdout, stderr) => {
            resolve({
                errno,
                stdout,
                stderr
            });
            cleanup();
        };

        // Execute the command
        try {
            // `ksu.exec` is provided by the KernelSU environment
            ksu.exec(command, JSON.stringify(options), callbackName);
        } catch (error) {
            reject(error);
            cleanup();
        }
    });
}

/**
 * Displays a toast message using the KernelSU API.
 * @param {string} message The message to display.
 */
function showToast(message) {
    // `ksu.toast` is provided by the KernelSU environment
    ksu.toast(message);
}

/**
 * Checks the installed module version and updates the UI.
 */
async function checkModuleVersion() {
    const command = "grep \"version=\" /data/adb/modules/hollow/module.prop | awk -F'=' '{print $2}'";
    try {
        const {
            errno,
            stdout
        } = await executeCommand(command);
        if (errno === 0) {
            document.getElementById('moduleVer').textContent = 'v' + stdout.trim();
        }
    } catch (error) {
        console.error("Error checking module version:", error);
    }
}

/**
 * Sets the selected thermal mode.
 * @param {string} mode The thermal mode to set (e.g., 'Normal', 'Intense').
 */
async function setThermalMode(mode) {
    const command = `echo ${mode} > /data/hollow/thermal_mode`;
    await executeCommand(command);
    showToast(`Set to ${mode}: Reboot needs`);
}

/**
 * Loads available thermal modes from the module directory and sets the current mode in the UI.
 */
async function loadThermalModes() {
    try {
        // Fetch available modes
        const {
            errno: modesErrno,
            stdout: modesStdout
        } = await executeCommand("cat /data/adb/modules/hollow/mode");

        if (modesErrno === 0) {
            const modes = modesStdout.trim().split(/\s+/);
            const thermalSelect = document.getElementById('thermal');

            // Clear existing options
            thermalSelect.innerHTML = '<option value="none" selected>None</option>';

            // Add new options
            modes.forEach(mode => {
                if (mode.trim()) {
                    const option = document.createElement('option');
                    option.value = mode;
                    option.textContent = mode;
                    thermalSelect.appendChild(option);
                }
            });

            // Fetch the currently active mode
            const {
                errno: currentModeErrno,
                stdout: currentModeStdout
            } = await executeCommand('cat /data/hollow/thermal_mode 2>/dev/null || echo none');

            if (currentModeErrno === 0) {
                const currentMode = currentModeStdout.trim();
                if (currentMode && currentMode !== 'none') {
                    thermalSelect.value = currentMode;
                }
            }
        }
    } catch (error) {
        console.error("Error loading thermal modes:", error);
    }
}

/**
 * Displays a random message in the status card.
 */
function showRandomMessage() {
    const messages = [
        "Even Stellar, Its only a Dream.",
        "Is Time Over",
        "Escape",
        "Lost Feeling",
        "Never Try",
        "Depressed",
        "Negative Space.",
        "Always Rude",
        "Ruined my time",
        "Time less",
        "Never Mind",
        "Is You Weak"
    ];
    const msgElement = document.getElementById('msg');
    const randomIndex = Math.floor(Math.random() * messages.length);
    msgElement.textContent = messages[randomIndex];
}

// Main execution block
document.addEventListener('DOMContentLoaded', async () => {
    // Initial setup
    await checkModuleVersion();
    await loadThermalModes();
    showRandomMessage();

    // Event listener for the thermal mode dropdown
    document.getElementById('thermal').addEventListener('change', async function() {
        if (this.value !== 'none') {
            await setThermalMode(this.value);
        }
    });
});