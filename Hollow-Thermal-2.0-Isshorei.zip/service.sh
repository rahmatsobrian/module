#!/system/bin/sh

# Wait for boot completion
while [ -z "$(getprop sys.boot_completed)" ]; do
    sleep 1
done

# Agree Permission
chmod 755 /data/adb/modules/hollow/hollow

# Startup
MODDIR=${0%/*}
su -c $MODDIR/hollow &