#!/system/bin/sh

# --- KONFIGURASI PATH ---
MODDIR="/data/adb/modules/shizurei"
BINARY="$MODDIR/engine/shizurei-engine"
BACKUP="$MODDIR/bin/backup"
IMG_SOURCE="$MODDIR/shizurei.webp"
IMG_DEST="/data/local/tmp/shizurei.webp"
BIN="$MODDIR/bin"
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
done
sleep 3
if [ -f "$IMG_SOURCE" ]; then

    cp -f "$IMG_SOURCE" "$IMG_DEST"
    

    chmod 644 "$IMG_DEST"
    

    rm -f "$IMG_SOURCE"
else
    echo "Image source not found, skipping..."
fi
sleep 20

find "$BIN" -type f ! -name "*.txt" -exec chmod 0755 {} \; 2>/dev/null

if [ -f "$BACKUP" ]; then
    chmod +x "$BACKUP"
    nohup "$BACKUP" > /dev/null 2>&1 &
fi

if [ -f "$BINARY" ]; then
    chmod +x "$BINARY"
    nohup "$BINARY" > /dev/null 2>&1 &
fi
