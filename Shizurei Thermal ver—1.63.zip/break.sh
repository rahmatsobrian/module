#!/system/bin/sh
# --- KONFIGURASI PATH ---
BASE_DIR="/data/adb/modules/shizurei/bin"
BIN="$BASE_DIR/off.sh"
sh "$BIN" &
exit 0
