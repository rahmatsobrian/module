#!/system/bin/sh
TMP="/data/local/tmp"
rm -f "$TMP/shizurei.webp"