#!/system/bin/sh
# --- KONFIGURASI PATH ---
BASE_DIR="/data/adb/modules/shizurei"
MODE_FILE="$BASE_DIR/mode/thermal-mode.txt"
BIN_DIR="$BASE_DIR/bin"

if [ ! -f "$MODE_FILE" ]; then
    echo "[Gate] Error: File mode tidak ditemukan di $MODE_FILE"
    exit 1
fi
MODE=$(cat "$MODE_FILE" | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]')

TARGET_SCRIPT=""

case "$MODE" in
    "extreme")
        TARGET_SCRIPT="$BIN_DIR/extreme.sh"
        ;;
    "lite")
        TARGET_SCRIPT="$BIN_DIR/lite.sh"
        ;;
    *)
        echo "[Gate] Unknown mode: '$MODE'. No action taken."
        exit 0
        ;;
esac

if [ -f "$TARGET_SCRIPT" ]; then
    echo "[Gate] Mode: $MODE -> Executing $TARGET_SCRIPT"
    sh "$TARGET_SCRIPT" &
    exit 0
else
    echo "[Gate] Error: Script tujuan tidak ditemukan ($TARGET_SCRIPT)"
    exit 0
fi
