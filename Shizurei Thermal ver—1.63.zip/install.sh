#!/system/bin/sh

SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE="
"

print_modname() {


ui_print "████████████████████████████████████████████"
sleep 0.05
ui_print "█─▄▄▄▄█─█─█▄─▄█░▄▄░▄█▄─██─▄█▄─▄▄▀█▄─▄▄─█▄─▄█"
sleep 0.05
ui_print "█▄▄▄▄─█─▄─██─███▀▄█▀██─██─███─▄─▄██─▄█▀██─██"
sleep 0.05
ui_print "▀▄▄▄▄▄▀▄▀▄▀▄▄▄▀▄▄▄▄▄▀▀▄▄▄▄▀▀▄▄▀▄▄▀▄▄▄▄▄▀▄▄▄▀"
sleep 0.05
  ui_print ""
  sleep 1
  ui_print "Made by : kaminarich | kaminarich_here"
    ui_print ""
}

on_install() {


  ui_print "> Merging into reality ..."
  sleep 2

  
  ui_print "> Extracting module files..."
  
  unzip -o "$ZIPFILE" 'bin/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'webroot/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'service.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'engine/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'mode/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'gate.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'break.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'shizurei.webp' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'gamelist.txt' -d $MODPATH >&2
  

  ui_print " "
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0777 0777
}
