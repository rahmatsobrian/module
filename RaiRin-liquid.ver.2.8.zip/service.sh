#!/system/bin/sh
MODDIR="/data/adb/modules/rairin-liquid"
BIN="$MODDIR/rairin-service-juice"
chmod +x "$BIN"
"$BIN"
