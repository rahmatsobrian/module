#!/system/bin/sh
MODDIR="/data/adb/modules/rairin-liquid"
BIN="$MODDIR/rairin-post-liquid"
chmod +x "$BIN"
chmod +x "$MODDIR/service.sh"
"$BIN"