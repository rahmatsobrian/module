#!/system/bin/sh

SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE="
"

print_modname() {
  # Banner: RAIRIN
  ui_print " "
  ui_print "░█▀▄░█▀█░▀█▀░█▀▄░▀█▀░█▀█"
  sleep 0.05
  ui_print "░█▀▄░█▀█░░█░░█▀▄░░█░░█░█"
  sleep 0.05
  ui_print "░▀░▀░▀░▀░▀▀▀░▀░▀░▀▀▀░▀░▀"
  ui_print " "
  ui_print "░█░░░█░█▀█░█░█░█░█▀▄"
  sleep 0.05
  ui_print "░█░░░█░▀▀█░█░█░█░█░█"
  sleep 0.05
  ui_print "░▀▀▀░▀░░░▀░▀▀▀░▀░▀▀░"
  sleep 0.05
  ui_print " "
  sleep 1
  ui_print "Made by : kaminarich | kaminarich_here"
  ui_print " "
}

on_install() {
  ui_print "> Merging into reality ..."
  sleep 1.5
  ui_print "> Extracting module files..."
  
  unzip -o "$ZIPFILE" 'post-fs-data.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'rairin-post-liquid' -d $MODPATH >&2 
  unzip -o "$ZIPFILE" 'rairin-service-juice' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'service.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'skiagl-soft' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'RaiRin-toast.apk' -d $MODPATH >&2
  
  ui_print "> Installing Toast Application"
  pm install $MODPATH/RaiRin-toast.apk
  ui_print " "
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0777 0777
}
