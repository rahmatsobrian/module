Check https://android-review.googlesource.com/c/platform/system/logging/+/3725346 for details.

Unlike other implementations, this fork allows fixing AVC log leak detection for users without SusFS or ZygiskNext.

Also see https://github.com/brunoanc/AuditPatch-KPM for a more discrete version for APatch, SukiSU users.
